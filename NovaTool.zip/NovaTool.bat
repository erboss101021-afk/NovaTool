@echo off
chcp 65001 >nul
color 4
title NovaTool

:menu
cls
echo  ███▄    █ ▒█████   ██▒   █▓ ▄▄▄        ▄▄▄█████▓ ▒█████   ▒█████   ██▓    
echo  ██ ▀█   █▒██▒  ██▒▓██░   █▒▒████▄   ▓     ██▒ ▓▒▒██▒  ██▒▒██▒  ██▒▓██▒    
echo ▓██  ▀█ ██▒██░  ██▒ ▓██  █▒░▒██  ▀█▄ ▒    ▓██░ ▒░▒██░  ██▒▒██░  ██▒▒██░    
echo ▓██▒  ▐▌██▒██   ██░  ▒██ █░░░██▄▄▄▄██░    ▓██▓ ░ ▒██   ██░▒██   ██░▒██░    
echo ▒██░   ▓██░ ████▓▒░   ▒▀█░   ▓█   ▓██▒    ▒██▒ ░ ░ ████▓▒░░ ████▓▒░░██████▒ v.1.0
echo ░ ▒░   ▒ ▒░ ▒░▒░▒░    ░ ▐░   ▒▒   ▓▒█░    ▒ ░░   ░ ▒░▒░▒░ ░ ▒░▒░▒░ ░ ▒░▓  ░
echo ░ ░░   ░ ▒░ ░ ▒ ▒░    ░ ░░    ▒   ▒▒ ░     ░      ░ ▒ ▒░   ░ ▒ ▒░ ░ ░ ▒  ░
echo    ░   ░ ░░ ░ ░ ▒       ░░    ░   ▒       ░      ░ ░ ░ ▒  ░ ░ ░ ▒    ░ ░   
echo          ░    ░ ░       ░░        ░   ░            ░ ░      ░ ░      ░  ░
echo.
echo Made by Er_Boss
echo.
echo ╔═══════════════════════════════════════════════╗
echo ║                                               ║
echo ║        1 - OSINT                              ║
echo ║        2 - Playlist                           ║
echo ║        3 - DiscordNuker                       ║
echo ║        4 - Credits                            ║
echo ║                                               ║
echo ╚═══════════════════════════════════════════════╝
echo.

set /p a=Select an option: 
if "%a%"=="1" goto OSINT
if "%a%"=="2" goto Playlist
if "%a%"=="3" goto DiscordNuker  
if "%a%"=="4" goto Credits

echo [!] Invalid Choice. Please try again... [!]
pause
goto menu

:OSINT
cls
echo  ███▄    █ ▒█████   ██▒   █▓ ▄▄▄        ▄▄▄█████▓ ▒█████   ▒█████   ██▓    
echo  ██ ▀█   █▒██▒  ██▒▓██░   █▒▒████▄   ▓     ██▒ ▓▒▒██▒  ██▒▒██▒  ██▒▓██▒    
echo ▓██  ▀█ ██▒██░  ██▒ ▓██  █▒░▒██  ▀█▄ ▒    ▓██░ ▒░▒██░  ██▒▒██░  ██▒▒██░    
echo ▓██▒  ▐▌██▒██   ██░  ▒██ █░░░██▄▄▄▄██░    ▓██▓ ░ ▒██   ██░▒██   ██░▒██░    
echo ▒██░   ▓██░ ████▓▒░   ▒▀█░   ▓█   ▓██▒    ▒██▒ ░ ░ ████▓▒░░ ████▓▒░░██████▒ v.1.0
echo ░ ▒░   ▒ ▒░ ▒░▒░▒░    ░ ▐░   ▒▒   ▓▒█░    ▒ ░░   ░ ▒░▒░▒░ ░ ▒░▒░▒░ ░ ▒░▓  ░
echo ░ ░░   ░ ▒░ ░ ▒ ▒░    ░ ░░    ▒   ▒▒ ░     ░      ░ ▒ ▒░   ░ ▒ ▒░ ░ ░ ▒  ░
echo    ░   ░ ░░ ░ ░ ▒       ░░    ░   ▒       ░      ░ ░ ░ ▒  ░ ░ ░ ▒    ░ ░   
echo          ░    ░ ░       ░░        ░   ░            ░ ░      ░ ░      ░  ░
echo.
echo Made by Er_Boss
echo.
echo ╔═══════════════════════════════════════════════╗
echo ║                                               ║
echo ║        1 - DoxTracker                         ║
echo ║        2 - SkipTracer                         ║
echo ║                                               ║
echo ╚═══════════════════════════════════════════════╝
echo      99 - Back
echo.


set /p a=Select an option:
if "%a%"=="1" goto DoxTracker
if "%a%"=="2" goto SkipTracer
if "%a%"=="99" goto menu  

echo [!] Invalid Choice. Please try angain... [!]
pause 
goto menu

:DoxTracker
wt -w 0 nt python "C:\Users\User\NovaTool\OSINT\DoxTracker.py"
goto menu

:SkipTracer
wt -w 0 nt python "C:\Users\User\NovaTool\OSINT\SkipTracer.py"
goto menu

:Playlist
cls
echo  ███▄    █ ▒█████   ██▒   █▓ ▄▄▄        ▄▄▄█████▓ ▒█████   ▒█████   ██▓    
echo  ██ ▀█   █▒██▒  ██▒▓██░   █▒▒████▄   ▓     ██▒ ▓▒▒██▒  ██▒▒██▒  ██▒▓██▒    
echo ▓██  ▀█ ██▒██░  ██▒ ▓██  █▒░▒██  ▀█▄ ▒    ▓██░ ▒░▒██░  ██▒▒██░  ██▒▒██░    
echo ▓██▒  ▐▌██▒██   ██░  ▒██ █░░░██▄▄▄▄██░    ▓██▓ ░ ▒██   ██░▒██   ██░▒██░    
echo ▒██░   ▓██░ ████▓▒░   ▒▀█░   ▓█   ▓██▒    ▒██▒ ░ ░ ████▓▒░░ ████▓▒░░██████▒ v.1.0
echo ░ ▒░   ▒ ▒░ ▒░▒░▒░    ░ ▐░   ▒▒   ▓▒█░    ▒ ░░   ░ ▒░▒░▒░ ░ ▒░▒░▒░ ░ ▒░▓  ░
echo ░ ░░   ░ ▒░ ░ ▒ ▒░    ░ ░░    ▒   ▒▒ ░     ░      ░ ▒ ▒░   ░ ▒ ▒░ ░ ░ ▒  ░
echo    ░   ░ ░░ ░ ░ ▒       ░░    ░   ▒       ░      ░ ░ ░ ▒  ░ ░ ░ ▒    ░ ░   
echo          ░    ░ ░       ░░        ░   ░            ░ ░      ░ ░      ░  ░
echo.
echo Made by Er_Boss
echo.
echo ╔═══════════════════════════════════════════════╗
echo ║                                               ║
echo ║        1 - PlaylistGenerator                  ║
echo ║        2 - SpotifyDownloader                  ║
echo ║                                               ║
echo ╚═══════════════════════════════════════════════╝
echo      99 - Back  
echo.

set /p a=Select an option:
if "%a%"=="1" goto PlaylistGenerator
if "%a%"=="2" goto SpotifyDownloader
if "%a%"=="99" goto menu  

echo [!] Invalid Choice. Please try angain... [!]
pause 
goto menu

:PlaylistGenerator
wt -w 0 nt python "C:\Users\User\NovaTool\DownloaderPlaylist\PlaylistGenerator.py"
goto menu

:SpotifyDownloader
wt -w 0 nt python "C:\Users\User\NovaTool\DownloaderPlaylist\SpotifyDownloader.py"
goto menu

:Credits
elif Tracker == "3":
start https://github.com/erboss101021-afk
goto menu 

:DiscordNuker  
wt -w 0 nt python "C:\Users\User\NovaTool\Shadow-Nuker\Shadow.py"
goto menu