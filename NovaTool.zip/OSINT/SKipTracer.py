#!/usr/bin/env python

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                           
#   ~ SkipTracer ~                            
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# CoDeD: bY Er_BOss
# DaTe: 23/08/2026
# Dev: Python
#
#~~~~~~~~~~~ INFO ~~~~~~~~~~~~
#
#     Simple Osint tool
#
#*****************************

import sys, os, time, signal, webbrowser, platform, subprocess
from urllib.parse import quote_plus

#~~~~ Keybord interruption ~~~~
def signal_handler(signal, frame):
		KURO()
		LOGO()
		print('\033[31m [\033[31mX\033[31m] You pressed Ctrl+C!')
		time.sleep(2)
		EXITMENU()
signal.signal(signal.SIGINT, signal_handler)

#~~~ Function KURO ~~~~
def KURO():
	if os.name == 'nt':
            os.system('cls')
	else:
            os.system('clear')

#~~~~ M E N U ~~~~
def LOGO():
    KURO()
    print("""\033[31m
███████╗██╗  ██╗██╗██████╗ ████████╗██████╗  █████╗  ██████╗███████╗██████╗ 
██╔════╝██║ ██╔╝██║██╔══██╗╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝██╔══██╗
███████╗█████╔╝ ██║██████╔╝   ██║   ██████╔╝███████║██║     █████╗  ██████╔╝
╚════██║██╔═██╗ ██║██╔═══╝    ██║   ██╔══██╗██╔══██║██║     ██╔══╝  ██╔══██╗
███████║██║  ██╗██║██║        ██║   ██║  ██║██║  ██║╚██████╗███████╗██║  ██║
╚══════╝╚═╝  ╚═╝╚═╝╚═╝        ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝╚═╝  ╚═╝V.1.0
""")
    print("\033[31mMade by Er_Boss\033[0m")
    

def menu():
	LOGO()
	time.sleep(1) 
    
	print("""\033[31m
 If you have to use tool n°4 use a VPN like https://protonvpn.com 
 ╔═══════════════════════════════════════════════╗
 ║                                               ║
 ║  1 - Email            5 - Screen Name         ║
 ║  2 - Name             6 - License Plate       ║
 ║  3 - Phone            7 - Profiler            ║
 ║  4 - Doxbin           8 - Help                ║
 ║                                               ║
 ║                                               ║
 ╚═══════════════════════════════════════════════╝      \033[31m
================================================================================
\033[31m    0 - Exit  \033[31m
        """)
	OPT = input("\033[31m Select\033[31m a\033[31m number\033[31m: ")
	if OPT == "1":
		 EMAIL()
	elif OPT == "2":
		 ID()
	elif OPT == "3":
		 PHONE()
	elif OPT == "4":
		 DOXBIN()
	elif OPT == "5":
		 SCREENNAME()
	elif OPT == "6":
		 LICENSE()
	elif OPT == "7":
		 PROFILER()
	elif OPT == "8":
		 HELP()
	elif OPT == "0":
		EXITMENU()
	else:
		KURO()
		LOGO()
		print("\033[31m[ERROR]\033[31m selection invalid!")
		time.sleep(3)
		menu()

def ID():
	KURO()
	LOGO()  
	time.sleep(1)
	Name = input("\033[31m Name:\033[31m ")
	Surname = input("\033[31m Surname:\033[31m ")
	SearchName = quote_plus(Name + " " + Surname)

	print("""\033[31m
 ╔════════════════════════════════════════════════════════════╗
 ║                                                            ║
 ║  1 - Google       6 - Youtube     11 - PeekYou             ║
 ║  2 - Facebook     7 - Reddit      12 - TruePeapleSearch    ║
 ║  3 - Instagram    8 - GitHub      13 - Whitepages          ║
 ║  4 - Tiktok       9 - Threads     14 - Legacy              ║
 ║  5 - LinkedIn     10 - Bluesky    15 - Google News         ║
 ║  00 - All                                                  ║
 ║                                                            ║
 ╚════════════════════════════════════════════════════════════╝    \033[31m
================================================================================
\033[31m    99. Back\033[31m    
		""")
	Tracker = input("\033[31m Select\033[31m a\033[31m number\033[31m: ")

	if Tracker == "1":
		KURO()
		webbrowser.open('https://www.google.com/search?q='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "2":
		KURO()
		webbrowser.open('https://www.facebook.com/search/top/?q='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "3":
		KURO()
		webbrowser.open('https://www.instagram.com/explore/search/keyword/?q='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "4":
		KURO()
		webbrowser.open('https://www.tiktok.com/search?q='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "5":
		KURO()
		webbrowser.open('https://www.linkedin.com/search/results/people/?keywords='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "6":
		KURO()
		webbrowser.open('https://www.youtube.com/results?search_query='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "7":
		KURO()
		webbrowser.open('https://www.reddit.com/search/?q='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "8":
		KURO()
		webbrowser.open('https://github.com/search?q='+SearchName+'&type=users')
		time.sleep(2)
		menu()
	elif Tracker == "9":
		KURO()
		webbrowser.open('https://www.threads.net/search?q='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "10":
		KURO()
		webbrowser.open('https://bsky.app/search?q='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "11":
		KURO()
		webbrowser.open('https://www.peekyou.com/search?name='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "12":
		KURO()
		webbrowser.open('https://www.truepeoplesearch.com/results?name='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "13":
		KURO()
		webbrowser.open('https://www.whitepages.com/name/'+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "14":
		KURO()
		webbrowser.open('https://www.legacy.com/search?name='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "15":
		KURO()
		webbrowser.open('https://news.google.com/search?q='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "00":
		KURO()
		for url in (
			'https://www.google.com/search?q='+SearchName,
			'https://www.facebook.com/search/top/?q='+SearchName,
			'https://www.instagram.com/explore/search/keyword/?q='+SearchName,
			'https://www.tiktok.com/search?q='+SearchName,
			'https://www.linkedin.com/search/results/people/?keywords='+SearchName,
			'https://www.youtube.com/results?search_query='+SearchName,
			'https://www.reddit.com/search/?q='+SearchName,
			'https://github.com/search?q='+SearchName+'&type=users',
			'https://www.threads.net/search?q='+SearchName,
			'https://bsky.app/search?q='+SearchName,
			'https://www.peekyou.com/search?name='+SearchName,
			'https://www.truepeoplesearch.com/results?name='+SearchName,
			'https://www.whitepages.com/name/'+SearchName,
			'https://www.legacy.com/search?name='+SearchName,
			'https://news.google.com/search?q='+SearchName,
		):
			webbrowser.open(url)
			time.sleep(2)
		menu()
	elif Tracker == "99":
		KURO()
		menu()
	else:
		KURO()
		LOGO()
		print ("\033[31m[ERROR]\033[31m selection invalid!")
		time.sleep(3)
		menu()

def EMAIL():
	KURO()
	LOGO()
	print("\033[31mEmail - SkipTracer module\033[0m")
	value = quote_plus(input("\033[31mEmail:\033[0m ").strip())
	print("""\033[31m
 ╔════════════════════════════════════════════════════════════╗
 ║  1 - LinkedIn-Sales       4 - WhoisAmped                   ║
 ║  2 - HaveIBeenPwned       5 - AdvancedBackgroundChecks     ║
 ║  3 - Myspace                                               ║
 ║  00 - All                                                  ║
 ╚════════════════════════════════════════════════════════════╝        \033[0m
 ================================================================================
\033[31m    99. Back\033[31m 
 """)
	Tracker = input(" Select a number: ").strip()
	if Tracker == "1":
		webbrowser.open("https://www.google.com/search?q="+value+"+LinkedIn")
	elif Tracker == "2":
		webbrowser.open("https://haveibeenpwned.com/account/"+value)
	elif Tracker == "3":
		webbrowser.open("https://myspace.com/search?q="+value)
	elif Tracker == "4":
		webbrowser.open("https://www.google.com/search?q="+value+"+whois")
	elif Tracker == "5":
		webbrowser.open("https://www.google.com/search?q="+value+"+email+lookup")
	elif Tracker == "00":
		for url in (
			"https://www.google.com/search?q="+value+"+LinkedIn",
			"https://haveibeenpwned.com/account/"+value,
			"https://myspace.com/search?q="+value,
			"https://www.google.com/search?q="+value+"+whois",
			"https://www.google.com/search?q="+value+"+email+lookup",
		):
			webbrowser.open(url)
			time.sleep(2)
	elif Tracker == "99":
		menu()
	else:
		print("[ERROR] selection invalid!")
	time.sleep(2)
	menu()

def SCREENNAME():
	KURO()
	LOGO()
	print("\033[31mScreen Name - SkipTracer module\033[0m")
	value = quote_plus(input("\033[31mUsername:\033[0m ").strip())
	print("""\033[31m
 ╔════════════════════════════════════════════════════════════╗
 ║  1 - Twitter              3 - NameChk                      ║
 ║  2 - Knowem               4 - Tinder                       ║
 ║  00 - All                 99 - Back          0 - Exit      ║
 ╚════════════════════════════════════════════════════════════╝\033[0m""")
	Tracker = input(" Select a number: ").strip()
	if Tracker == "1":
		webbrowser.open("https://twitter.com/search?q="+value)
	elif Tracker == "2":
		webbrowser.open("https://knowem.com/checkusernames.php?u="+value)
	elif Tracker == "3":
		webbrowser.open("https://namechk.com/?q="+value)
	elif Tracker == "4":
		webbrowser.open("https://www.google.com/search?q="+value+"+Tinder")
	elif Tracker == "00":
		for url in (
			"https://twitter.com/search?q="+value,
			"https://knowem.com/checkusernames.php?u="+value,
			"https://namechk.com/?q="+value,
			"https://www.google.com/search?q="+value+"+Tinder",
		):
			webbrowser.open(url)
			time.sleep(2)
	elif Tracker == "99":
		menu()
	elif Tracker == "0":
		EXITMENU()
	else:
		print("[ERROR] selection invalid!")
	time.sleep(2)
	menu()

def LICENSE():
	KURO()
	LOGO()
	print("\033[31mLicense Plate - SkipTracer module\033[0m")
	value = quote_plus(input("\033[31mLicense plate:\033[0m ").strip())
	print("""\033[31m
 ╔════════════════════════════════════════════════════════════╗
 ║                                                            ║
 ║  1 - funnik             00 - ALL                           ║
 ║  2 - Vehiclescore                                          ║
 ║                                                            ║
 ╚════════════════════════════════════════════════════════════╝\033[0m
================================================================================
\033[31m    99. Back\033[31m
""")
	Tracker = input(" Select a number: ").strip()
	if Tracker == "1":
		webbrowser.open("https://finnik.nl/en"+value)
	elif Tracker == "2":
		webbrowser.open("https://vehiclescore.co.uk/"+value)
	elif Tracker == "00":
		for url in (
			"https://finnik.nl/en"+value,
			"https://vehiclescore.co.uk/"+value,
		):
			webbrowser.open(url)
			time.sleep(2)
	elif Tracker == "99":
		menu()
	else:
		print("[ERROR] selection invalid!")
	time.sleep(2)
	menu()

def PROFILER():
	KURO()
	LOGO()
	print("\033[31mProfiler - SkipTracer guided profile\033[0m")
	print("Enter the requested data or press Enter to skip a field.")
	input("First name: ")
	input("Last name: ")
	input("Age range: ")
	input("City or state: ")
	input("Known phone: ")
	input("Known username: ")
	input("Email: ")
	print("\nProfile collected. No data is saved locally.")
	input("Press Enter to return to menu...")

def HELP():
	KURO()
	LOGO()
	print("\033[31mSkipTracer modules:\033[0m")
	print("Email, Name, Phone, Screen Name, License Plate, Profiler, Doxbin self-check")
	print("Edit the URLs directly within the file's functions.")
	input("\nPress Enter to return to menu...")

def DOXBIN():
	KURO()
	LOGO()
	print("\033[31mDoxbin self-check\033[0m")
	print("Public and defensive check: only enter your own data.")
	value = quote_plus(input("\033[31mNome, username o email:\033[0m ").strip())
	webbrowser.open("https://doxbin.com/?search=title&query="+value)
	input("\nPress Enter to return to menu...")

def PHONE():
	KURO()
	LOGO()  
	time.sleep(1)
	Num = input("\033[31mNumber:\033[31m ")
	value = quote_plus(Num.strip())
	print("""\033[31m
 ╔════════════════════════════════════════════════════════════╗
 ║                                                            ║
 ║ 1 - True People          3 - Four One One                  ║
 ║ 2 - Who Called           4 - AdvancedBackgroundChecks      ║
 ║ 00 - All                                                   ║
 ║                                                            ║
 ╚════════════════════════════════════════════════════════════╝\033[0m
================================================================================
\033[31m    99. Back\033[31m
 """)
	Tracker = input(" Select a number: ").strip()
	if Tracker == "1":
		webbrowser.open("https://www.truepeoplesearch.com/results?phoneno="+value)
	elif Tracker == "2":
		webbrowser.open("https://www.google.com/search?q="+value+"+who+called")
	elif Tracker == "3":
		webbrowser.open("https://www.google.com/search?q="+value+"+411+directory")
	elif Tracker == "4":
		webbrowser.open("https://www.google.com/search?q="+value+"+phone+lookup")
	elif Tracker == "00":
		for url in (
			"https://www.truepeoplesearch.com/results?phoneno="+value,
			"https://www.google.com/search?q="+value+"+who+called",
			"https://www.google.com/search?q="+value+"+411+directory",
			"https://www.google.com/search?q="+value+"+phone+lookup",
		):
			webbrowser.open(url)
			time.sleep(2)
	elif Tracker == "99":
		menu()
	else:
		print("[ERROR] selection invalid!")
	time.sleep(2)
	menu()

#~~~~ EXIT ~~~~
def EXITMENU():
	KURO()
	LOGO()
	time.sleep(1)
	print("\033[31m Thanks for using DoxTracker\033[31m")
	time.sleep(2)
	print("\033[31m[\033[31mX\033[31m]...\033[31mClosing")
	time.sleep(1)
	KURO()
	sys.exit()
		
menu()
