#!/usr/bin/env python

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                           
#   ~ DoxTracker 1.0 beta ~                            
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# CoDeD: bY KURO-CODE
# DaTe: 03/12/2017
# Dev: Python
#
#~~~~~~~~~~~ INFO ~~~~~~~~~~~~
#
#     Simple Doxing tool
#
#*****************************

import sys, os, time, signal, webbrowser, platform, subprocess
from urllib.parse import quote_plus

#~~~~ Keybord interruption ~~~~
def signal_handler(signal, frame):
		KURO()
		LOGO()
		print('\033[31m [\033[31mX\033[31m] You pressed Ctrl+C!')
		time.sleep(2)
		EXITMENU()
signal.signal(signal.SIGINT, signal_handler)

#~~~ Function KURO ~~~~
def KURO():
	if os.name == 'nt':
            os.system('cls')
	else:
            os.system('clear')

#~~~~ M E N U ~~~~
def LOGO():
    KURO()
    print("""\033[31m
██████╗  ██████╗ ██╗  ██╗    ████████╗██████╗  █████╗  ██████╗██╗  ██╗███████╗██████╗
██╔══██╗██╔═══██╗╚██╗██╔╝    ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗
██║  ██║██║   ██║ ╚███╔╝        ██║   ██████╔╝███████║██║     █████╔╝ █████╗  ██████╔╝
██║  ██║██║   ██║ ██╔██╗        ██║   ██╔══██╗██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗
██████╔╝╚██████╔╝██╔╝ ██╗       ██║   ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║
╚═════╝  ╚═════╝ ╚═╝  ╚═╝       ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝v.1.0
""")
    print("\033[31mMade by Er_Boss\033[0m")

def menu():
	LOGO()
	time.sleep(1) 
	print("""\033[31m
 ╔═══════════════════════════════════════════════╗
 ║                                               ║
 ║  1 - Name            3 - Dead                 ║
 ║  2 - Phone number    4 - IP                   ║
 ║                                               ║
 ║                                               ║
 ╚═══════════════════════════════════════════════╝      \033[31m
================================================================================
\033[31m    0 - Exit  \033[31m
        """)
	OPT = input("\033[31m Select\033[31m a\033[31m number\033[31m: ")
	if OPT == "1":
         ID()
	elif OPT == "2":
		 PHONE()
	elif OPT == "3":
		 DEAD()
	elif OPT == "4":
		 IP()
	elif OPT == "0":
		EXITMENU()
	else:
		KURO()
		LOGO()
		print("\033[31m[ERROR]\033[31m selection invalid!")
		time.sleep(3)
		menu()

def ID():
	KURO()
	LOGO()  
	time.sleep(1)
	Name = input("\033[31m Name:\033[31m ")
	Surname = input("\033[31m Surname:\033[31m ")
	SearchName = quote_plus(Name + " " + Surname)

	print("""\033[31m
 ╔════════════════════════════════════════════════════════════╗
 ║                                                            ║
 ║  1 - Google       6 - Youtube     11 - PeekYou             ║
 ║  2 - Facebook     7 - Reddit      12 - TruePeapleSearch    ║
 ║  3 - Instagram    8 - GitHub      13 - Whitepages          ║
 ║  4 - Tiktok       9 - Threads     14 - Legacy              ║
 ║  5 - LinkedIn     10 - Bluesky    15 - Google News         ║
 ║  00 - All                                                  ║
 ║                                                            ║
 ╚════════════════════════════════════════════════════════════╝    \033[31m
================================================================================
\033[31m    99. Back\033[31m    
		""")
	Tracker = input("\033[31m Select\033[31m a\033[31m number\033[31m: ")

	if Tracker == "1":
		KURO()
		webbrowser.open('https://www.google.com/search?q='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "2":
		KURO()
		webbrowser.open('https://www.facebook.com/search/top/?q='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "3":
		KURO()
		webbrowser.open('https://www.instagram.com/explore/search/keyword/?q='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "4":
		KURO()
		webbrowser.open('https://www.tiktok.com/search?q='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "5":
		KURO()
		webbrowser.open('https://www.linkedin.com/search/results/people/?keywords='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "6":
		KURO()
		webbrowser.open('https://www.youtube.com/results?search_query='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "7":
		KURO()
		webbrowser.open('https://www.reddit.com/search/?q='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "8":
		KURO()
		webbrowser.open('https://github.com/search?q='+SearchName+'&type=users')
		time.sleep(2)
		menu()
	elif Tracker == "9":
		KURO()
		webbrowser.open('https://www.threads.net/search?q='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "10":
		KURO()
		webbrowser.open('https://bsky.app/search?q='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "11":
		KURO()
		webbrowser.open('https://www.peekyou.com/search?name='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "12":
		KURO()
		webbrowser.open('https://www.truepeoplesearch.com/results?name='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "13":
		KURO()
		webbrowser.open('https://www.whitepages.com/name/'+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "14":
		KURO()
		webbrowser.open('https://www.legacy.com/search?name='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "15":
		KURO()
		webbrowser.open('https://news.google.com/search?q='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "00":
		KURO()
		for url in (
			'https://www.google.com/search?q='+SearchName,
			'https://www.facebook.com/search/top/?q='+SearchName,
			'https://www.instagram.com/explore/search/keyword/?q='+SearchName,
			'https://www.tiktok.com/search?q='+SearchName,
			'https://www.linkedin.com/search/results/people/?keywords='+SearchName,
			'https://www.youtube.com/results?search_query='+SearchName,
			'https://www.reddit.com/search/?q='+SearchName,
			'https://github.com/search?q='+SearchName+'&type=users',
			'https://www.threads.net/search?q='+SearchName,
			'https://bsky.app/search?q='+SearchName,
			'https://www.peekyou.com/search?name='+SearchName,
			'https://www.truepeoplesearch.com/results?name='+SearchName,
			'https://www.whitepages.com/name/'+SearchName,
			'https://www.legacy.com/search?name='+SearchName,
			'https://news.google.com/search?q='+SearchName,
		):
			webbrowser.open(url)
			time.sleep(2)
		menu()
	elif Tracker == "99":
		KURO()
		menu()
	else:
		KURO()
		LOGO()
		print ("\033[31m[ERROR]\033[31m selection invalid!")
		time.sleep(3)
		menu()

def PHONE():
	KURO()
	LOGO()  
	time.sleep(1)
	Num = input("\033[31mNumber:\033[31m ")

	print("""\033[31m
 ╔═══════════════════════════════════════════════╗
 ║                                               ║
 ║  1 - Okcaller          6 - Canada411          ║
 ║  2 - Facebook          7 - Pagesjaunes        ║
 ║  3 - France-inverse    8 - Truecaller         ║
 ║  4 - Whitepages        9 - NumLookup          ║
 ║  5 - Anywho            10 - Should I Answer   ║
 ║  00 - All                                     ║
 ║                                               ║
 ╚═══════════════════════════════════════════════╝    \033[31m
================================================================================
\033[31m    99. Back\033[31m
		""")
	Tracker = input("\033[31m Select\033[31m a\033[31m number\033[31m: ")

	if Tracker == "1":
		KURO()
		webbrowser.open('http://www.okcaller.com/'+Num)
		time.sleep(2)
		menu()
	elif Tracker == "2":
		KURO()
		webbrowser.open('https://www.facebook.com/search/top/?init=quick&q='+Num)
		time.sleep(2)
		menu()
	elif Tracker == "3":
		KURO()
		webbrowser.open('http://www.france-inverse.com/annuaire-inverse/'+Num)
		time.sleep(2)
		menu()
	elif Tracker == "4":
		KURO()
		webbrowser.open('https://www.whitepages.com/phone/'+Num)
		time.sleep(2)
		menu()
	elif Tracker == "5":
		KURO()
		webbrowser.open('https://www.anywho.com/phone/'+Num)
		time.sleep(2)
		menu()
	elif Tracker == "6":
		KURO()
		webbrowser.open('http://canada411.pagesjaunes.ca/fs/'+Num)
		time.sleep(2)
		menu()
	elif Tracker == "7":
		KURO()
		webbrowser.open('https://www.pagesjaunes.fr/annuaireinverse/recherche?quoiqui='+Num)
		time.sleep(2)
		menu()
	elif Tracker == "8":
		KURO()
		webbrowser.open('https://www.truecaller.com/search/us/'+Num)
		time.sleep(2)
		menu()
	elif Tracker == "9":
		KURO()
		webbrowser.open('https://www.numlookup.com/'+Num)
		time.sleep(2)
		menu()
	elif Tracker == "10":
		KURO()
		webbrowser.open('https://www.shouldianswer.com/phone-number/'+Num)
		time.sleep(2)
		menu()
	elif Tracker == "00":
		KURO()
		webbrowser.open('http://www.okcaller.com/'+Num)
		time.sleep(2)
		webbrowser.open('https://www.facebook.com/search/top/?init=quick&q='+Num)
		time.sleep(2)
		webbrowser.open('http://www.france-inverse.com/annuaire-inverse/'+Num)
		time.sleep(2)
		webbrowser.open('https://www.whitepages.com/phone/'+Num)
		time.sleep(2)
		webbrowser.open('https://www.anywho.com/phone/'+Num)
		time.sleep(2)
		webbrowser.open('http://canada411.pagesjaunes.ca/fs/'+Num)
		time.sleep(2)
		webbrowser.open('https://www.pagesjaunes.fr/annuaireinverse/recherche?quoiqui='+Num)
		time.sleep(2)
		webbrowser.open('https://www.truecaller.com/search/us/'+Num)
		time.sleep(2)
		webbrowser.open('https://www.numlookup.com/'+Num)
		time.sleep(2)
		webbrowser.open('https://www.shouldianswer.com/phone-number/'+Num)
		time.sleep(2)
		menu()
	elif Tracker == "99":
		KURO()
		menu()
	else:
		KURO()
		LOGO() 
		print("\033[31m[ERROR]\033[31m selection invalid!")
		time.sleep(3)
		menu()

def DEAD():
	KURO()
	LOGO()
	Name = input("\033[31mName:\033[31m ")
	Surname = input("\033[31mSurnamename:\033[31m ")
	SearchName = quote_plus(Name + " " + Surname)

	print("""\033[31m
 ╔══════════════════════════════════════════╗
 ║                                          ║
 ║  1 - Libramemoria     4 - Find a Grave   ║
 ║  2 - Avis-de-deces    5 - Legacy         ║
 ║  3 - Enmemoria        6 - Google         ║
 ║  00 - All                                ║
 ║                                          ║
 ╚══════════════════════════════════════════╝    \033[31m
================================================================================
\033[31m    99. Back\033[31m   
		""")
	Tracker = input("\033[31m Select\033[31m a\033[31m number\033[31m: ")
	if Tracker == "1":
		KURO()
		webbrowser.open('http://www.libramemoria.com/avis/?Nom='+Name+'&Prenom='+Surname)
		time.sleep(2)
		menu()
	elif Tracker == "2":
		KURO()
		webbrowser.open('https://www.avis-de-deces.net/avis/par-nom/?lastname='+Name+'&firstname='+Surname)
		time.sleep(2)
		menu()
	elif Tracker == "3":
		KURO()
		webbrowser.open('http://enmemoria.lavanguardia.com/buscar?keywords='+Name+'+'+Surname+'&type=death&_fstatus=search')
		time.sleep(2)
		menu()
	elif Tracker == "4":
		KURO()
		webbrowser.open('https://www.findagrave.com/memorial/search?firstname='+quote_plus(Name)+'&lastname='+quote_plus(Surname))
		time.sleep(2)
		menu()
	elif Tracker == "5":
		KURO()
		webbrowser.open('https://www.legacy.com/search?name='+SearchName)
		time.sleep(2)
		menu()
	elif Tracker == "6":
		KURO()
		webbrowser.open('https://www.google.com/search?q='+SearchName+'+obituary')
		time.sleep(2)
		menu()
	elif Tracker == "00":
		KURO()
		time.sleep(2)
		webbrowser.open('http://www.libramemoria.com/avis/?Nom='+Name+'&Prenom='+Surname)
		time.sleep(2)
		webbrowser.open('https://www.avis-de-deces.net/avis/par-nom/?lastname='+Name+'&firstname='+Surname)
		time.sleep(2)
		webbrowser.open('http://enmemoria.lavanguardia.com/buscar?keywords='+Name+'+'+Surname+'&type=death&_fstatus=search')
		time.sleep(2)
		webbrowser.open('https://www.findagrave.com/memorial/search?firstname='+quote_plus(Name)+'&lastname='+quote_plus(Surname))
		time.sleep(2)
		webbrowser.open('https://www.legacy.com/search?name='+SearchName)
		time.sleep(2)
		webbrowser.open('https://www.google.com/search?q='+SearchName+'+obituary')
		time.sleep(2)
		menu()
	elif Tracker == "99":
		KURO()
		menu()
	else:
		KURO()
		LOGO()
		print("\033[31m[ERROR]\033[31m selection invalid!")
		time.sleep(3)
		menu()

def IP():
	KURO()
	LOGO()
	ip = input(" Ip:\033[31m ")

	print("""\033[31m
 ╔═════════════════════════════════════════════╗
 ║                                             ║
 ║  1 - G-force               4 - IPinfo       ║
 ║  2 - whatismyipaddress     5 - IPLocation   ║
 ║  3 - Whois                 6 - AbuseIPDB    ║
 ║  00 - All                                   ║
 ║                                             ║
 ╚═════════════════════════════════════════════╝     \033[31m
================================================================================
\033[31m    99. Back\033[31m    
		""")	
	Tracker = input("\033[31m Select\033[31m a\033[31m number\033[31m: ")
	if Tracker == "1":
		KURO()
		webbrowser.open('https://www.g-force.ca/en/hosting/ip-whois?ip='+ip)
		time.sleep(2)
		menu()
	elif Tracker == "2":
		KURO()
		webbrowser.open('http://whatismyipaddress.com/ip/'+ip)
		time.sleep(2)
		menu()
	elif Tracker == "3":
		KURO()
		webbrowser.open('https://dig.whois.com.au/ip/'+ip)
		time.sleep(2)
		menu()
	elif Tracker == "4":
		KURO()
		webbrowser.open('https://ipinfo.io/'+ip)
		time.sleep(2)
		menu()
	elif Tracker == "5":
		KURO()
		webbrowser.open('https://www.iplocation.com/ip/'+ip)
		time.sleep(2)
		menu()
	elif Tracker == "6":
		KURO()
		webbrowser.open('https://www.abuseipdb.com/check/'+ip)
		time.sleep(2)
		menu()
	elif Tracker == "00":
		KURO()
		time.sleep(2)
		webbrowser.open('https://www.g-force.ca/en/hosting/ip-whois?ip='+ip)
		time.sleep(2)
		webbrowser.open('http://whatismyipaddress.com/ip/'+ip)
		time.sleep(2)
		webbrowser.open('https://dig.whois.com.au/ip/'+ip)
		time.sleep(2)
		webbrowser.open('https://ipinfo.io/'+ip)
		time.sleep(2)
		webbrowser.open('https://www.iplocation.com/ip/'+ip)
		time.sleep(2)
		webbrowser.open('https://www.abuseipdb.com/check/'+ip)
		time.sleep(2)
		menu()
	elif Tracker == "99":
		KURO()
		menu()
	else:
		KURO()
		LOGO()
		print("\033[31m[ERROR]\033[31m selection invalid!")
		time.sleep(3)
		menu()

#~~~~ EXIT ~~~~
def EXITMENU():
	KURO()
	LOGO()
	time.sleep(1)
	print("\033[31m Thanks for using DoxTracker\033[31m")
	time.sleep(2)
	print("\033[31m[\033[31mX\033[31m]...\033[31mClosing")
	time.sleep(1)
	KURO()
	sys.exit()
		
menu()
