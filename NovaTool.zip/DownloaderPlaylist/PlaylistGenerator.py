#!/usr/bin/env python3
"""
Playlist Generator - Apre TuneMyMusic nel browser con la query incollata.

Uso:
    python playlist_generator.py

Requisiti opzionali (per automazione perfetta):
    pip install selenium webdriver-manager pyautogui pyperclip
"""

import sys
import os
import subprocess
import time
import webbrowser


# --- Helper per testo rosso ---
def rprint(*args, **kwargs):
    print("\033[31m", end="")
    print(*args, **kwargs)
    print("\033[0m", end="", flush=True)
    print("\033[31m", end="", flush=True)


def rinput(prompt=""):
    print("\033[31m" + prompt, end="", flush=True)
    return input()


def open_tunemymusic(query: str) -> None:
    """Apre TuneMyMusic nel browser e incolla la query nel campo di ricerca."""
    url = "https://www.tunemymusic.com/it/features/playlist-generator"

    # ========== METODO 1: SELENIUM (più affidabile) ==========
    try:
        from selenium import webdriver
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.chrome.options import Options
        from selenium.webdriver.chrome.service import Service
        from webdriver_manager.chrome import ChromeDriverManager

        options = Options()
        options.add_argument("--start-maximized")
        # Evita il banner "Chrome è controllato da un software automatizzato"
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)

        rprint("[1/3] Avvio Chrome con Selenium...")
        driver = webdriver.Chrome(
            service=Service(ChromeDriverManager().install()),
            options=options
        )
        driver.get(url)

        rprint("[1/3] Pagina caricata. Attendo il campo di input (max 20s)...")
        wait = WebDriverWait(driver, 20)

        # Cerca il campo con molti selettori diversi
        selectors = [
            ("placeholder contains playlist", "input[placeholder*='playlist' i]"),
            ("placeholder contains genera", "input[placeholder*='genera' i]"),
            ("placeholder contains cerca", "input[placeholder*='cerca' i]"),
            ("placeholder contains search", "input[placeholder*='search' i]"),
            ("placeholder contains type", "input[placeholder*='type' i]"),
            ("type=text", "input[type='text']"),
            ("type=search", "input[type='search']"),
            ("textarea", "textarea"),
            ("contenteditable", "[contenteditable='true']"),
            ("any input", "input"),
        ]

        search_box = None
        used_selector = None
        for name, sel in selectors:
            try:
                rprint(f"[1/3] Provo selettore: {name}...")
                search_box = wait.until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, sel))
                )
                if search_box.is_displayed():
                    used_selector = name
                    rprint(f"[1/3] ✓ Trovato campo con: {name}")
                    break
            except Exception:
                continue

        if search_box is None:
            raise Exception("Nessun campo di ricerca trovato con i selettori noti")

        # Clicca sul campo per assicurarti che abbia il focus
        search_box.click()
        time.sleep(0.3)
        search_box.clear()
        search_box.send_keys(query)

        rprint("\n[1/3] ✓ TuneMyMusic aperto con Selenium.")
        rprint("[1/3] ✓ Testo inserito automaticamente nel campo.")
        rprint("\nGenera la playlist sul sito, poi premi INVIO qui per chiudere Chrome.")
        rinput()
        driver.quit()
        return

    except ImportError:
        rprint("[1/3] ✗ Selenium non installato.")
        rprint("    Installa con: pip install selenium webdriver-manager")
        rprint("    Procedo con il metodo pyautogui...")
    except Exception as e:
        rprint(f"[1/3] ✗ Selenium errore: {e}")
        rprint("    Procedo con il metodo pyautogui...")

    # ========== METODO 2: PYAUTOGUI + TAB ==========
    try:
        import pyautogui
        import pyperclip

        pyperclip.copy(query)

        rprint("[2/3] Apertura browser predefinito...")
        if not webbrowser.open_new_tab(url):
            raise RuntimeError("Impossibile aprire il browser.")

        rprint("[2/3] Attendo caricamento (8s)...")
        time.sleep(8)

        # Porta il browser in primo piano
        if os.name == "nt":
            rprint("[2/3] Porto il browser in primo piano...")
            subprocess.run([
                "powershell", "-NoProfile", "-Command",
                '$ws = New-Object -ComObject WScript.Shell; '
                '$titles = @("TuneMyMusic","Playlist Generator",'
                '"Google Chrome","Microsoft Edge","Mozilla Firefox","Brave"); '
                'foreach ($t in $titles) { if ($ws.AppActivate($t)) { break } }'
            ], capture_output=True)

        time.sleep(1)

        # Chiudi eventuali popup/banner
        rprint("[2/3] Chiudo eventuali popup...")
        pyautogui.press('esc')
        time.sleep(0.3)

        # Naviga con TAB (molti TAB per sicurezza)
        rprint("[2/3] Navigo verso il campo con TAB (30 pressioni)...")
        for i in range(30):
            pyautogui.press('tab')
            time.sleep(0.15)

        # Incolla
        rprint("[2/3] Incollo il testo...")
        pyautogui.keyDown('ctrl')
        pyautogui.keyDown('v')
        pyautogui.keyUp('v')
        pyautogui.keyUp('ctrl')

        rprint("\n[2/3] ✓ TuneMyMusic aperto.")
        rprint("[2/3] ✓ Testo incollato nel campo con pyautogui.")
        return

    except ImportError:
        rprint("[2/3] ✗ pyautogui non installato.")
        rprint("    Installa con: pip install pyautogui pyperclip")
    except Exception as e:
        rprint(f"[2/3] ✗ pyautogui fallito: {e}")

    # ========== METODO 3: FALLBACK MANUALE ==========
    rprint("[3/3] Apro il sito in modalità manuale...")
    webbrowser.open_new_tab(url)
    rprint(f"\n[3/3] TuneMyMusic aperto. Copia manualmente questo testo nel campo:")
    rprint(f"  {query}")


def main():
    print("""\033[31m
██████╗ ██╗      █████╗ ██╗   ██╗██╗     ██╗███████╗████████╗     ██████╗ ███████╗███╗   ██╗
██╔══██╗██║     ██╔══██╗╚██╗ ██╔╝██║     ██║██╔════╝╚══██╔══╝    ██╔════╝ ██╔════╝████╗  ██║
██████╔╝██║     ███████║ ╚████╔╝ ██║     ██║███████╗   ██║       ██║  ███╗█████╗  ██╔██╗ ██║
██╔═══╝ ██║     ██╔══██║  ╚██╔╝  ██║     ██║╚════██║   ██║       ██║   ██║██╔══╝  ██║╚██╗██║
██║     ███████╗██║  ██║   ██║   ███████╗██║███████║   ██║       ╚██████╔╝███████╗██║ ╚████║
╚═╝     ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝╚══════╝   ╚═╝        ╚═════╝ ╚══════╝╚═╝  ╚═══╝v.1.0
""")
    print("\033[31mMade by Er_Boss\033[0m")
    print()

    playlist_type = rinput(
        "Che tipo di playlist vuoi? (es. 'rock anni 80', 'workout gym', "
        "'relax study'): "
    ).strip()

    if not playlist_type:
        rprint("Nessuna query inserita. Uscita.")
        sys.exit(0)

    open_tunemymusic(playlist_type)
    rprint("\nIl sito TuneMyMusic è stato aperto nel browser.")
    rprint("Genera la playlist e goditi la musica!\n")

    rinput("Premi INVIO per chiudere...")
    print("\033[0m", end="", flush=True)


if __name__ == "__main__":
    main()