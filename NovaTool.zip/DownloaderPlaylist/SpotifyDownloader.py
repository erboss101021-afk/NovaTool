#!/usr/bin/env python3
"""
Spotify Playlist Downloader
============================
Scarica una playlist Spotify come file audio.

COME FUNZIONA (leggi prima di usarlo):
    Spotify cripta i suoi stream audio (DRM): non è tecnicamente possibile
    scaricare l'audio originale direttamente da Spotify. Questo script quindi:
      1. Legge titoli/artisti/copertine della playlist tramite l'API ufficiale
         di Spotify (spotipy)
      2. Cerca il brano corrispondente su YouTube
      3. Lo scarica e converte in audio con yt-dlp (stesso motore usato per
         YouTube Music)

    È lo stesso approccio usato da tool noti come "spotdl".

Requisiti (da installare sul tuo computer):
    pip install spotipy yt-dlp
    ffmpeg nel PATH (https://ffmpeg.org/download.html)

Come ottenere le chiavi API di Spotify (gratis, 2 minuti):
    1. Vai su https://developer.spotify.com/dashboard
    2. Accedi con il tuo account Spotify (anche free va bene)
    3. Crea una nuova app (basta un nome a caso, es. "Playlist Downloader")
       - Come "Redirect URI" metti: http://127.0.0.1:8888/callback
       - Seleziona "Web API" come API/SDK
    4. Copia "Client ID" e "Client Secret"

Come salvare le chiavi una volta per tutte:
    python spotify_downloader.py --configure

    Questo le salva in config.json accanto allo script: ai prossimi avvii
    non te le richiederà più. In alternativa puoi anche usare variabili
    d'ambiente (SPOTIFY_CLIENT_ID/SPOTIFY_CLIENT_SECRET) o passarle con
    --client-id/--client-secret ogni volta.

Uso:
    python spotify_downloader.py --configure
    python spotify_downloader.py "https://open.spotify.com/playlist/XXXX"

    # oppure passando le chiavi direttamente, senza salvarle:
    python spotify_downloader.py "URL_PLAYLIST" \\
        --client-id XXXX --client-secret YYYY --format mp3

Note legali:
    Usa questo script solo per playlist e brani che hai il diritto di
    scaricare (musica tua, Creative Commons/royalty-free, o backup personale
    dove consentito dalla legge del tuo paese). Scaricare musica protetta da
    copyright senza autorizzazione può violare i Termini di Servizio di
    Spotify/YouTube e la legge sul copyright del tuo paese. Il matching tra
    brano Spotify e video YouTube è automatico e potrebbe occasionalmente
    trovare la versione sbagliata (live, cover, ecc.).
"""

import argparse
import json
import os
import re
import sys
import webbrowser

try:
    import spotipy
    from spotipy.oauth2 import SpotifyClientCredentials
except ImportError:
    print("ERRORE: spotipy non è installato.")
    print("Installalo con:  pip install spotipy")
    sys.exit(1)

try:
    import yt_dlp
except ImportError:
    print("ERRORE: yt-dlp non è installato.")
    print("Installalo con:  pip install yt-dlp")
    sys.exit(1)

# Titolo della scheda/finestra del terminale (funziona su Windows con cmd/Windows Terminal)
if os.name == "nt":
    os.system("title Spotify Downloader - NovaTool")

# Cartella di default: sempre accanto a questo script, indipendentemente
# da dove viene lanciato (es. doppio click da .bat con working directory diversa)
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_OUTPUT_DIR = os.path.join(SCRIPT_DIR, "downloads")
CONFIG_FILE = os.path.join(SCRIPT_DIR, "config.json")


def load_config() -> dict:
    """Legge le chiavi salvate da config.json, se esiste."""
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_config(client_id: str, client_secret: str):
    """Salva le chiavi in config.json accanto allo script."""
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump({"client_id": client_id, "client_secret": client_secret}, f, indent=2)
    print(f"Chiavi salvate in: {CONFIG_FILE}")


def configure():
    """Modalità impostazioni: chiede le chiavi e le salva su file."""
    print("=== Impostazioni Spotify ===")
    print()
    client_id = input("Spotify Client ID: ").strip()
    client_secret = input("Spotify Client Secret: ").strip()
    if not client_id or not client_secret:
        print("Client ID/Secret vuoti, impostazioni non salvate.")
        sys.exit(1)
    save_config(client_id, client_secret)


def check_ffmpeg():
    import shutil
    if shutil.which("ffmpeg") is None:
        print("ATTENZIONE: ffmpeg non trovato nel PATH.")
        print("La conversione audio potrebbe fallire.")
        print("Installa ffmpeg: https://ffmpeg.org/download.html")
        print()


def extract_playlist_id(url_or_id: str) -> str:
    """Estrae l'ID playlist da un URL Spotify, oppure lo restituisce se già puro."""
    match = re.search(r"playlist/([a-zA-Z0-9]+)", url_or_id)
    if match:
        return match.group(1)
    return url_or_id.strip()


def get_spotify_client(client_id: str, client_secret: str):
    auth_manager = SpotifyClientCredentials(
        client_id=client_id, client_secret=client_secret
    )
    return spotipy.Spotify(auth_manager=auth_manager)


def get_playlist_tracks(sp, playlist_id: str):
    """Restituisce lista di dict {title, artist, album} per ogni brano."""
    tracks = []
    results = sp.playlist_items(playlist_id, additional_types=["track"])

    while results:
        for item in results["items"]:
            track = item.get("track")
            if not track:
                continue
            title = track.get("name")
            artists = ", ".join(a["name"] for a in track.get("artists", []))
            album = track.get("album", {}).get("name", "")
            if title and artists:
                tracks.append({"title": title, "artist": artists, "album": album})
        results = sp.next(results) if results.get("next") else None

    return tracks


def sanitize_filename(name: str) -> str:
    return re.sub(r'[\\/*?:"<>|]', "_", name)


def progress_hook(d):
    """Mostra la percentuale di avanzamento del download corrente."""
    if d["status"] == "downloading":
        percent = d.get("_percent_str", "").strip()
        speed = d.get("_speed_str", "").strip()
        sys.stdout.write(f"\r     {percent}  {speed}      ")
        sys.stdout.flush()
    elif d["status"] == "finished":
        sys.stdout.write("\r     conversione...              \n")
        sys.stdout.flush()


def download_track(query: str, output_path: str, audio_format: str, quality: str):
    """Cerca 'query' su YouTube e scarica il primo risultato come audio."""
    ydl_opts = {
        "format": "bestaudio/best",
        "outtmpl": output_path,
        "default_search": "ytsearch1",
        "postprocessors": [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": audio_format,
            "preferredquality": quality,
        }],
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "embedthumbnail": True,
        "addmetadata": True,
        "ignoreerrors": True,
        "progress_hooks": [progress_hook],
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        ydl.download([query])


def download_playlist(playlist_url: str, output_dir: str, audio_format: str,
                       quality: str, client_id: str, client_secret: str,
                       numbered: bool):

    os.makedirs(output_dir, exist_ok=True)

    print("Connessione a Spotify...")
    sp = get_spotify_client(client_id, client_secret)
    playlist_id = extract_playlist_id(playlist_url)

    print("Lettura brani della playlist...")
    tracks = get_playlist_tracks(sp, playlist_id)

    if not tracks:
        print("Nessun brano trovato. Controlla l'URL della playlist.")
        return

    print(f"Trovati {len(tracks)} brani. Inizio ricerca e download da YouTube...")
    print("-" * 50)

    for i, track in enumerate(tracks, start=1):
        search_query = f"{track['artist']} - {track['title']} audio"
        safe_title = sanitize_filename(f"{track['artist']} - {track['title']}")

        if numbered:
            filename = f"{i:03d} - {safe_title}.%(ext)s"
        else:
            filename = f"{safe_title}.%(ext)s"

        output_path = os.path.join(output_dir, filename)

        print(f"[{i}/{len(tracks)}] {track['artist']} - {track['title']}")
        try:
            download_track(search_query, output_path, audio_format, quality)
        except Exception as e:
            print(f"   -> Errore, brano saltato: {e}")

    print("-" * 50)
    print("Download completato.")
    print(f"File salvati in: {os.path.abspath(output_dir)}")


def main():
    parser = argparse.ArgumentParser(
        description="Scarica una playlist Spotify cercando i brani su YouTube."
    )
    parser.add_argument("url", nargs="?", default=None,
                         help="URL o ID della playlist Spotify (se omesso, verrà richiesto)")
    parser.add_argument(
        "-o", "--output", default=DEFAULT_OUTPUT_DIR,
        help=f"Cartella di destinazione (default: {DEFAULT_OUTPUT_DIR})"
    )
    parser.add_argument(
        "-f", "--format", default="mp3",
        choices=["mp3", "flac", "wav", "m4a", "opus", "vorbis"],
        help="Formato audio di output (default: mp3)"
    )
    parser.add_argument(
        "-q", "--quality", default="192",
        help="Qualità audio (es. 128, 192, 320 per mp3)"
    )
    parser.add_argument(
        "--client-id", default=None,
        help="Spotify Client ID (sovrascrive config.json e variabile d'ambiente)"
    )
    parser.add_argument(
        "--client-secret", default=None,
        help="Spotify Client Secret (sovrascrive config.json e variabile d'ambiente)"
    )
    parser.add_argument(
        "--configure", action="store_true",
        help="Imposta o aggiorna Client ID/Secret salvandoli in config.json ed esce"
    )
    parser.add_argument(
        "--no-numbering", action="store_true",
        help="Non aggiungere il numero di posizione nel nome file"
    )

    args = parser.parse_args()

    print("""\033[31m
███████╗██████╗  ██████╗ ████████╗██╗███████╗██╗   ██╗    ██████╗ ██╗     
██╔════╝██╔══██╗██╔═══██╗╚══██╔══╝██║██╔════╝╚██╗ ██╔╝    ██╔══██╗██║     
███████╗██████╔╝██║   ██║   ██║   ██║█████╗   ╚████╔╝     ██║  ██║██║     
╚════██║██╔═══╝ ██║   ██║   ██║   ██║██╔══╝    ╚██╔╝      ██║  ██║██║     
███████║██║     ╚██████╔╝   ██║   ██║██║        ██║       ██████╔╝███████╗
╚══════╝╚═╝      ╚═════╝    ╚═╝   ╚═╝╚═╝        ╚═╝       ╚═════╝ ╚══════╝v.1.0                              
    \033[31m""")
    print("\033[31mMade by Er_Boss\033[0m")
    print()

    if args.configure:
        configure()
        return

    config = load_config()

    # Ordine di priorità: argomento da riga di comando > variabile d'ambiente > config.json
    client_id = args.client_id or os.environ.get("SPOTIFY_CLIENT_ID") or config.get("client_id")
    client_secret = args.client_secret or os.environ.get("SPOTIFY_CLIENT_SECRET") or config.get("client_secret")

    if not client_id or not client_secret:
        print("Nessuna chiave Spotify trovata (config.json, variabili d'ambiente o argomenti).")
        print()
        client_id = input("Spotify Client ID: ").strip()
        client_secret = input("Spotify Client Secret: ").strip()

        if not client_id or not client_secret:
            print("ERRORE: mancano le chiavi API di Spotify.")
            print("Vedi le istruzioni all'inizio del file per ottenerle.")
            sys.exit(1)

        save = input("Salvare queste chiavi per i prossimi avvii? (s/n) [s]: ").strip().lower()
        if save != "n":
            save_config(client_id, client_secret)

    url = args.url
    if not url:
        url = input("URL playlist Spotify: ").strip()
        if not url:
            print("URL vuoto, operazione annullata.")
            sys.exit(1)

        downloader_url = "https://spotidownloader.com/it19"

        def open_and_fill_spotidownloader(playlist_link: str):
            """Apre il browser e incolla il link nel campo di ricerca del sito."""
            import subprocess
            import shutil
            import time
            import os

            print("\nApertura del browser predefinito...")

            # ========== METODO 1: SELENIUM (più affidabile) ==========
            try:
                from selenium import webdriver
                from selenium.webdriver.common.by import By
                from selenium.webdriver.support.ui import WebDriverWait
                from selenium.webdriver.support import expected_conditions as EC
                from selenium.webdriver.chrome.options import Options
                from selenium.webdriver.chrome.service import Service
                from webdriver_manager.chrome import ChromeDriverManager

                options = Options()
                options.add_argument("--start-maximized")

                print("Avvio Chrome con Selenium...")
                driver = webdriver.Chrome(
                    service=Service(ChromeDriverManager().install()),
                    options=options
                )
                driver.get(downloader_url)

                # Attendi che il campo di ricerca appaia (max 20 secondi)
                wait = WebDriverWait(driver, 20)

                # Prova diversi selettori finché non trova il campo giusto
                selectors = [
                    "input[placeholder*='link' i]",
                    "input[placeholder*='cerca' i]",
                    "input[placeholder*='search' i]",
                    "input[type='text']",
                    "input[type='url']",
                    "input[type='search']",
                    "textarea",
                    "input"
                ]

                search_box = None
                for sel in selectors:
                    try:
                        search_box = wait.until(
                            EC.presence_of_element_located((By.CSS_SELECTOR, sel))
                        )
                        if search_box.is_displayed():
                            break
                    except Exception:
                        continue

                if search_box is None:
                    raise Exception("Campo di ricerca non trovato")

                search_box.clear()
                search_box.send_keys(playlist_link)

                print(f"\n✓ Browser aperto con Selenium: {downloader_url}")
                print("✓ Link inserito automaticamente nel campo di ricerca.")
                print(f"  {playlist_link}")
                print("\nOra puoi cliccare 'Scarica' nel browser.")
                print("Quando hai finito, premi INVIO in questo terminale per chiudere Chrome.")
                input()
                driver.quit()
                return

            except ImportError:
                print("Selenium non trovato. Provo con pyautogui...")
            except Exception as e:
                print(f"Selenium errore: {e}")
                print("Provo con pyautogui...")

            # ========== METODO 2: PYAUTOGUI + CLIC NEL CAMPO ==========
            try:
                import pyautogui
                import pyperclip

                pyperclip.copy(playlist_link)

                if not webbrowser.open_new_tab(downloader_url):
                    raise RuntimeError("Impossibile aprire il browser.")

                print("Attendo caricamento (6s)...")
                time.sleep(6)

                # Porta il browser in primo piano
                if os.name == "nt":
                    subprocess.run([
                        "powershell", "-NoProfile", "-Command",
                        '$ws = New-Object -ComObject WScript.Shell; '
                        '$titles = @("Spotify Downloader","SpotiDownloader",'
                        '"Google Chrome","Microsoft Edge","Mozilla Firefox","Brave"); '
                        'foreach ($t in $titles) { if ($ws.AppActivate($t)) { break } }'
                    ], capture_output=True)

                time.sleep(1)

                # Clicca nel punto dello schermo dove tipicamente c'è il campo
                # (centrato orizzontalmente, circa 30% dall'alto)
                w, h = pyautogui.size()
                pyautogui.click(w // 2, int(h * 0.30))
                time.sleep(0.5)

                # Incolla
                pyautogui.keyDown('ctrl')
                pyautogui.keyDown('v')
                pyautogui.keyUp('v')
                pyautogui.keyUp('ctrl')

                print(f"\n✓ Browser aperto: {downloader_url}")
                print("✓ Link inserito automaticamente nel campo.")
                print(f"  {playlist_link}")
                print("Ora puoi cliccare 'Scarica' nel browser.")
                return

            except ImportError:
                print("pyautogui non installato.")
            except Exception as e:
                print(f"pyautogui fallito: {e}")

            # ========== METODO 3: FALLBACK MANUALE ==========
            print("\nApertura del browser predefinito...")
            webbrowser.open_new_tab(downloader_url)
            print(f"Link copiato negli appunti:\n  {playlist_link}")
            print("Incollalo manualmente nel campo di ricerca (Ctrl+V).")

        try:
            open_and_fill_spotidownloader(url)
        except Exception as e:
            print("\nERRORE AUTOMAZIONE SPOTIDOWNLOADER")
            print(f"Dettaglio: {e}")
            print("\nApro comunque il sito nel browser predefinito...")
            webbrowser.open_new_tab(downloader_url)
            print("Il link è stato lasciato negli appunti: puoi fare Ctrl+V nel campo.")
    check_ffmpeg()

    try:
        download_playlist(
            playlist_url=url,
            output_dir=args.output,
            audio_format=args.format,
            quality=args.quality,
            client_id=client_id,
            client_secret=client_secret,
            numbered=not args.no_numbering,
        )
        input("\nPremi invio per chiudere...")
    except KeyboardInterrupt:
        print("\nDownload interrotto dall'utente.")
        sys.exit(1)
    except Exception as e:
        print(f"Errore durante il download: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()