@echo off
setlocal EnableExtensions

title NovaTool - Install Dependencies
color 04

REM Always run from the directory where this file is located.
cd /d "%~dp0"

echo.
echo ===============================================
echo        NovaTool - Dependency Installer
echo ===============================================
echo.

REM Prefer the Windows Python Launcher when available.
set "PYTHON_CMD="
where py >nul 2>&1
if not errorlevel 1 set "PYTHON_CMD=py -3"

if not defined PYTHON_CMD (
    where python >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=python"
)

if not defined PYTHON_CMD (
    echo [ERROR] Python was not found.
    echo Install Python 3.10 or newer from https://www.python.org/downloads/
    echo Make sure Python is added to PATH.
    goto :error
)

echo [INFO] Using Python:
%PYTHON_CMD% --version
if errorlevel 1 goto :error

set "VENV_DIR=%~dp0.venv"
set "VENV_PYTHON=%VENV_DIR%\Scripts\python.exe"

if not exist "%VENV_PYTHON%" (
    echo.
    echo [INFO] Creating virtual environment...
    %PYTHON_CMD% -m venv "%VENV_DIR%"
    if errorlevel 1 goto :error
)

echo.
echo [INFO] Updating pip...
"%VENV_PYTHON%" -m pip install --upgrade pip
if errorlevel 1 goto :error

echo.
echo [INFO] Installing playlist downloader dependencies...
"%VENV_PYTHON%" -m pip install spotipy yt-dlp
if errorlevel 1 goto :error

echo.
echo [INFO] Installing optional browser automation dependencies...
"%VENV_PYTHON%" -m pip install selenium webdriver-manager pyautogui pyperclip
if errorlevel 1 goto :error

if exist "%~dp0Shadow-Nuker\requirements.txt" (
    echo.
    echo [INFO] Installing Shadow-Nuker dependencies...
    "%VENV_PYTHON%" -m pip install -r "%~dp0Shadow-Nuker\requirements.txt"
    if errorlevel 1 goto :error
) else (
    echo.
    echo [WARNING] Shadow-Nuker\requirements.txt was not found.
    echo           Shadow-Nuker dependencies were skipped.
)

echo.
where ffmpeg >nul 2>&1
if errorlevel 1 (
    echo [WARNING] FFmpeg was not found in PATH.
    echo           Spotify audio conversion may not work.
    echo           Download FFmpeg from https://ffmpeg.org/download.html
) else (
    echo [INFO] FFmpeg detected.
)

echo.
echo ===============================================
echo        Dependencies installed successfully
echo ===============================================
echo.
echo The virtual environment is located at:
echo %VENV_DIR%
echo.
echo To use it manually in PowerShell:
echo .venv\Scripts\Activate.ps1
echo.
echo You can now run:
echo python DownloaderPlaylist\SpotifyDownloader.py
echo python DownloaderPlaylist\PlaylistGenerator.py
echo python OSINT\DoxTracker.py
echo python OSINT\SKipTracer.py
echo python Shadow-Nuker\Shadow.py
echo.
pause
exit /b 0

:error
echo.
echo ===============================================
echo        Dependency installation failed
echo ===============================================
echo.
pause
exit /b 1