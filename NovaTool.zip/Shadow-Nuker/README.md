# PATCHED ⚠️

<p align="center">
  <img src="assets/banner.jpg" alt="Shadow Nuker Banner" width="800" style="border-radius: 10px; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);" />
</p>

<h1 align="center">
  🔮 SHADOW NUKER 🔮
</h1>

<p align="center">
  <strong>Feel the Power. Control the Shadow.</strong>
</p>

<p align="center">
  <a href="https://github.com/Shadow-Black-YT/Shadow-Nuker/releases"><img src="https://img.shields.io/github/v/release/Shadow-Black-YT/Shadow-Nuker?color=8b5cf6&label=Portable%20Release&style=for-the-badge" alt="Release"></a>
  <img src="https://img.shields.io/github/license/Shadow-Black-YT/Shadow-Nuker?color=ec4899&style=for-the-badge" alt="License">
  <img src="https://img.shields.io/github/stars/Shadow-Black-YT/Shadow-Nuker?color=00f0ff&style=for-the-badge" alt="Stars">
  <img src="https://img.shields.io/github/forks/Shadow-Black-YT/Shadow-Nuker?color=34d399&style=for-the-badge" alt="Forks">
</p>

---

## ⚡ Introduction

**Shadow Nuker** is a premium, high-throughput, and beautifully designed Discord server management utility built with **Python 3.10+** and powered by a custom asynchronous rate-limiting bypass engine. Sporting a gorgeous retro-cyberpunk purple theme, it offers total control and blazing-fast executions for developers and security analysts auditing server security settings.

> [!IMPORTANT]
> This tool is strictly for educational, security auditing, and self-testing purposes. Using this tool on servers without explicit authorization is a violation of Discord's Terms of Service and local laws.

---

## 📸 Screenshots

<p align="center">
  <img src="assets/screenshot.jpg" alt="Shadow Nuker CLI Interface" width="800" style="border-radius: 8px; border: 2px solid #7c3aed;" />
</p>

---

## 🚀 Key Features

*   🌌 **Neon Cyberpunk UI**: Sleek styling with custom gradient animations using the `rich` console package.
*   ⚡ **Adaptive Concurrency REST Engine**: Custom rate-limit engine that actively monitors response headers, dynamically adjusting concurrency levels between `10` and `75` in-flight requests.
*   ⚡ **Smart Local & Global Queueing**: Staggers requests to avoid thundering-herd problems and respects IETF / Discord rate limit reset periods with random-jittered sleep.
*   📦 **Portable Executable**: Run it instantly without installing Python. Simply download the `.exe` from the Releases tab.
*   🛠️ **25+ Custom Modules**: Includes basic and advanced actions to perform server configuration checks, emoji management, soundboard updates, and automated moderation adjustments.

---

## 🎮 Modules List

| 🎯 Attack Modules (Basic) | 🎯 Attack Modules (Advanced) |
| :--- | :--- |
| 📩 DM Everyone on Server | 🖼️ Server Picture Change |
| 🎭 Role Create Spam | 🗑️ Delete All Emojis |
| 🗑️ Delete All Roles | 🎭 Spam New Emojis |
| 👑 Give Everyone Admin | 🔇 Delete All Sounds (Soundboard) |
| 🔔 Notification → All Messages | 🔊 Spam New Sounds (Soundboard) |
| 💥 Delete All Channels + VCs | 🔗 Delete All Invites |
| 📝 Spam Create Channels | 🔗 Spam New Invites |
| 📁 Spam Create Categories | 🛑 Pause Server Invites |
| 💬 Spam Channels (Messages) | 🤖 Deactivate AutoMod |
| 👢 Kick Everyone | ❌ Deactivate Community |
| 🔨 Ban Everyone | ✅ Activate Community |
| 🔓 Unban Everyone | 🧵 Thread Spam |
| ✏️ Server Name Change | 🚪 Clean Exit |

---

## 📥 Installation & Setup

### Option 1: Portable Executable (Recommended)
No installation required!
1. Go to the [Releases](https://github.com/Shadow-Black-YT/Shadow-Nuker/releases) page.
2. Download the latest `ShadowNuker.exe`.
3. Launch the `.exe` file on your Windows machine and paste your Discord bot token to start.

### Option 2: Running from Source
If you prefer running it using Python directly:
1. Clone this repository:
   ```bash
   git clone https://github.com/Shadow-Black-YT/Shadow-Nuker.git
   cd shadow-nuker
   ```
2. Install the required dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the script:
   ```bash
   python Shadow.py
   ```

---

## ⚙️ Requirements
*   `discord.py`
*   `aiohttp`
*   `rich`

These are pre-bundled in the compiled `.exe` executable.

---

## ⚠️ Educational Disclaimer
This repository is published for **educational purposes and security auditing only**. The author ("Nystic Shadow") accepts no responsibility for any misuse, damage, or legal issues arising from the use of this software. 

### 📩 Removal Request / Takedown Notice
If you are a copyright owner or a representative and believe this repository should be removed or modified, please send an email directly to:
👉 **[nysticshadow@gmail.com](mailto:nysticshadow@gmail.com)**
Your request will be handled promptly.

---

<p align="center">
  <sub>MIT Licensed • Made with 💜 by Nystic Shadow</sub>
</p>
